<?php
session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// pastikan ada id postingan
if (!isset($_GET['id'])) {
    die("ID postingan tidak ditemukan.");
}

$post_id = (int)$_GET['id'];

// Ambil data postingan
$stmt = $conn->prepare("SELECT * FROM posts WHERE id = ? AND user_id = ? LIMIT 1");
$stmt->bind_param("ii", $post_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Postingan tidak ditemukan atau bukan milik kamu.");
}

$post = $result->fetch_assoc();
$oldImage = $post['image'];

// Proses update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $deskripsi = $_POST['deskripsi'];

    // Jika user upload gambar baru
    if (!empty($_FILES['image']['name'])) {

        $file = $_FILES['image'];
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $newName = "post_" . time() . "." . $ext;
        $uploadPath = "uploads/" . $newName;

        if (move_uploaded_file($file['tmp_name'], $uploadPath)) {

            // hapus gambar lama jika ada
            if (!empty($oldImage) && file_exists($oldImage)) {
                unlink($oldImage);
            }

            // Update dengan gambar baru
            $update = $conn->prepare("UPDATE posts 
                                      SET title=?, deskripsi=?, image=? 
                                      WHERE id=? AND user_id=?");
            $update->bind_param("sssii", $title, $deskripsi, $uploadPath, $post_id, $user_id);

        } else {
            echo "<script>alert('Gagal upload gambar.');</script>";
        }

    } else {
        // Update tanpa ganti gambar
        $update = $conn->prepare("UPDATE posts 
                                  SET title=?, deskripsi=? 
                                  WHERE id=? AND user_id=?");
        $update->bind_param("ssii", $title, $deskripsi, $post_id, $user_id);
    }

    if (isset($update) && $update->execute()) {
        echo "<script>
                alert('Postingan berhasil diperbarui!');
                window.location='profile.php';
              </script>";
        exit;
    } else {
        echo "<script>alert('Gagal update postingan.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Postingan</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="InspirARTMedia.co">
	<link rel="shortcut icon" href="favicon.png">
	<meta name="deskripsi" content="">
	<meta name="keywords" content="art, blog, inspirart, upload">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

	<!-- Pastikan Bootstrap dimuat (template-mu memakai kelas bootstrap) -->
	<link rel="stylesheet" href="css/bootstrap.min.css">

	<link rel="stylesheet" href="css/tiny-slider.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/glightbox.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/flatpickr.min.css">
    <style>
        .edit-wrapper {
            max-width: 600px;
            margin: 40px auto;
        }

        .edit-card {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 14px rgba(0,0,0,0.12);
        }

        .edit-card img {
            width: 100%;
            border-radius: 8px;
            margin-bottom: 12px;
        }

        .top-title {
            font-weight: 700;
            text-align: center;
            margin-bottom: 25px;
        }


.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}

    </style>
</head>
<body>

<!-- NAVBAR -->
<nav class="site-nav">
		<div class="container">
			<div class="menu-bg-wrap">
				<div class="site-navigation">
					<div class="row g-0 align-items-center">
						<div class="col-2">
							<a href="dashboarduser.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
						</div>
						<div class="col-8 text-center">
							<ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
								<li><a href="dashboarduser.php">Home</a></li>
								<li><a href="profile.php">Profile</a></li>
								<li class="active"><a href="post.php">Post</a></li>
								<li><a href="category.php">Categories</a></li>
								<li><a href="aboutus.php">About Us</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</nav>

<div class="site-cover site-cover-sm same-height overlay single-page" style="background-image: url('https://i.pinimg.com/1200x/1d/c8/61/1dc8619487310884c9d631d689ece1e7.jpg');">
		<div class="container">
			<div class="row same-height justify-content-center">
				<div class="col-md-6">
					<div class="post-entry text-center">
						<h1 class="mb-4">EDIT POST</h1>
						<p class="text-white-50" data-aos="fade-up" data-aos-delay="100">Bagikan Postinganmu Kepada Dunia</p>
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- FORM EDIT -->
<div class="container edit-wrapper">
    <div class="edit-card">

        <h3 class="top-title">Edit Postingan</h3>

        <form method="POST" enctype="multipart/form-data">

            <label class="form-label">Judul</label>
            <input type="text" name="title" class="form-control mb-3"
                   value="<?php echo htmlspecialchars($post['title']); ?>" required>

            <label class="form-label">Deskripsi</label>
            <textarea name="deskripsi" class="form-control mb-3" rows="6" required><?php 
                echo htmlspecialchars($post['deskripsi']); 
            ?></textarea>

            <label class="form-label">Gambar Saat Ini</label>
            <img src="<?php echo $post['image']; ?>">

            <label class="form-label mt-3">Ganti Gambar (Opsional)</label>
            <input type="file" name="image" class="form-control mb-4">

            <button type="submit" class="btn btn-primary w-100">Update Postingan</button>

        </form>
    </div>
</div>

<script src="js/bootstrap.bundle.min.js"></script>

<!-- FOOTER -->
<?php include "footeruser.php"; ?>

<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>