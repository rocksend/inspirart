<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) {
  die("Silakan login terlebih dahulu.");
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  die("ID artikel tidak valid.");
}

$post_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

// === Hapus komentar ===
if (isset($_GET['action']) && $_GET['action'] === 'delete_comment' && isset($_GET['comment_id'])) {
    $comment_id = (int)$_GET['comment_id'];

    // Ambil role user
    $role_stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
    $role_stmt->bind_param("i", $user_id);
    $role_stmt->execute();
    $user_role = $role_stmt->get_result()->fetch_assoc()['role'] ?? 'user';
    $role_stmt->close();

    // Ambil pemilik posting
    $post_stmt = $conn->prepare("SELECT user_id FROM posts WHERE id = ?");
    $post_stmt->bind_param("i", $post_id);
    $post_stmt->execute();
    $post_data = $post_stmt->get_result()->fetch_assoc();
    $post_stmt->close();

    $post_owner_id = $post_data['user_id'];

    // Ambil data komentar
    $check_stmt = $conn->prepare("SELECT user_id FROM comments WHERE id = ?");
    $check_stmt->bind_param("i", $comment_id);
    $check_stmt->execute();
    $comment_data = $check_stmt->get_result()->fetch_assoc();
    $check_stmt->close();

    // HANYA admin / pemilik komentar / pemilik posting yang boleh hapus
    if ($comment_data && (
        $user_role === 'admin' ||
        $comment_data['user_id'] == $user_id ||
        $post_owner_id == $user_id
    )) {
        $del = $conn->prepare("DELETE FROM comments WHERE id = ?");
        $del->bind_param("i", $comment_id);
        $del->execute();
        $del->close();
    }

    // Kembali ke halaman yang benar
    header("Location: singledetail.php?id=$post_id");
    exit;
}

// === Ambil data artikel ===
$stmt = $conn->prepare("
  SELECT p.*, u.username, u.profile_img
  FROM posts p
  LEFT JOIN users u ON p.user_id = u.id
  WHERE p.id = ?

");
$stmt->bind_param("i", $post_id);
$stmt->execute();
$post = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$post) {
  die("Artikel tidak ditemukan.");
}

// === Tambah komentar ===
if (isset($_POST['submit_comment'])) {
  $comment = trim($_POST['comment']);
  $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : NULL;

  if ($comment !== '') {
    $stmt = $conn->prepare("INSERT INTO comments (post_id, user_id, parent_id, comment) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $post_id, $user_id, $parent_id, $comment);
    $stmt->execute();
    $stmt->close();
  }

  header("Location: singledetail.php?id=$post_id");
  exit;
}


// === Toggle Like (Like/Unlike) ===
if (isset($_POST['like'])) {
  $check = $conn->prepare("SELECT id FROM likes WHERE post_id=? AND user_id=?");
  $check->bind_param("ii", $post_id, $user_id);
  $check->execute();
  $check->store_result();

  if ($check->num_rows > 0) {
    // sudah like → unlike (hapus)
    $del = $conn->prepare("DELETE FROM likes WHERE post_id=? AND user_id=?");
    $del->bind_param("ii", $post_id, $user_id);
    $del->execute();
    $del->close();
  } else {
    // belum like → tambahkan
    $ins = $conn->prepare("INSERT INTO likes (post_id, user_id) VALUES (?, ?)");
    $ins->bind_param("ii", $post_id, $user_id);
    $ins->execute();
    $ins->close();
  }

  $check->close();

  header("Location: singledetail.php?id=$post_id");
  exit;
}

// === Ambil semua komentar (dengan waktu) ===
$cq = $conn->prepare("
  SELECT c.*, u.username 
  FROM comments c 
  JOIN users u ON c.user_id = u.id 
  WHERE c.post_id = ?
  ORDER BY c.created_at ASC
");
$cq->bind_param("i", $post_id);
$cq->execute();
$comments = $cq->get_result();

// === Ambil jumlah like & status user ===
$lq = $conn->prepare("SELECT COUNT(*) AS total FROM likes WHERE post_id=?");
$lq->bind_param("i", $post_id);
$lq->execute();
$likes_count = $lq->get_result()->fetch_assoc()['total'];
$lq->close();

$liked = false;
$check = $conn->prepare("SELECT id FROM likes WHERE post_id=? AND user_id=?");
$check->bind_param("ii", $post_id, $user_id);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
  $liked = true;
}
$check->close();


// === Ambil semua komentar ===
$cq = $conn->prepare("
  SELECT c.*, u.username 
  FROM comments c 
  JOIN users u ON c.user_id = u.id 
  WHERE c.post_id = ?
  ORDER BY c.created_at ASC
");
$cq->bind_param("i", $post_id);
$cq->execute();
$comments = $cq->get_result();

// === Ambil jumlah like ===
$lq = $conn->prepare("SELECT COUNT(*) AS total FROM likes WHERE post_id=?");
$lq->bind_param("i", $post_id);
$lq->execute();
$likes_count = $lq->get_result()->fetch_assoc()['total'];
$lq->close();
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>InspirART - Detail Post</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

	<!-- Pastikan Bootstrap dimuat (template-mu memakai kelas bootstrap) -->
	<link rel="stylesheet" href="css/bootstrap.min.css">

	<link rel="stylesheet" href="css/tiny-slider.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/glightbox.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/flatpickr.min.css">

<style>
    .btn-delete-comment {
      color: white;
      background-color: #dc3545;
      border: none;
      padding: 3px 8px;
      font-size: 12px;
      border-radius: 5px;
      text-decoration: none;
      margin-left: 10px;
    }
    .btn-delete-comment:hover {
      background-color: #c82333;
      color: white;
    }

.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}

/* Ensure comment blocks and textareas don't overflow horizontally */
.comments { overflow-wrap: break-word; }
.comments .form-control { box-sizing: border-box; max-width: 100%; }
.comments { padding-right: 1rem; }

</style>
</head>
<body>

<!-- NAVBAR -->
<nav class="site-nav">
  <div class="container">
    <div class="menu-bg-wrap">
      <div class="site-navigation">
        <div class="row g-0 align-items-center">
          <div class="col-2">
            <a href="dashboarduser.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
          </div>
          <div class="col-8 text-center">
            <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
              <li><a href="dashboarduser.php">Home</a></li>
              <li><a href="profile.php">Profile</a></li>
              <li><a href="post.php">Post</a></li>
              <li><a href="category.php">Categories</a></li>
              <li><a href="aboutus.php">About Us</a></li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</nav>

<!-- BANNER USER -->
<section class="section py-3" id="post-banner">
  <div class="container d-flex align-items-center">
    <img id="post-user-img" src="<?= htmlspecialchars($post['profile_img'] ?? 'images/default-user.png'); ?>" 
     alt="User" class="rounded-circle me-3" width="60" height="60">
    <div>
      <h6 class="mb-0" id="post-user-name"><?= htmlspecialchars($post['username'] ?? 'Anonymous'); ?></h6>
    </div>
  </div>
</section>

<!-- DETAIL POST -->
<section class="section bg-light" id="detailpost">
  <div class="container">
    <div id="post-detail" class="text-center">
      <h1 class="ms-2 mb-3"><?php echo htmlspecialchars($post['title']); ?></h1>
      <div style="margin-top:10px; display:flex; justify-content:center; align-items:center; gap:8px;">
    <span style="font-size:20px; color:#aaa;">
        ❤️
    </span>

    <span onclick="openLikersModal()" 
          style="cursor:pointer; font-weight:600;">
        <?= $likes_count ?> Likes
    </span>
</div>

         <h6 class="text-muted"><?php echo date('M d, Y', strtotime($post['created_at'])); ?></h6>
      <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" 
           class="img-fluid rounded mb-4" style="max-width:600px">
      <p class="lead"><?php echo nl2br(htmlspecialchars($post['deskripsi'])); ?></p>
      <p class="lead"><?php echo nl2br(htmlspecialchars($post['content'] ?? '')); ?></p>
    </div>
  </div>
</section>

<!-- Tombol Like (dipindah ke header komentar agar sejajar dengan tulisan 'Komentar') -->
<!-- (Form like sebelumnya dipindah ke dalam container komentar di bawah) -->

<!-- Komentar -->
<section class="comments mt-4">
  <div class="container pe-4">
    <div class="d-flex align-items-center justify-content-between">
      <h4 class="mb-0">Komentar</h4>
      <form method="post" class="d-inline-block ms-3 mb-0">
        <button type="submit" name="like" class="btn btn-outline-danger">
          ❤️ Like (<?= $likes_count; ?>)
        </button>
      </form>
    </div>

    <form method="post" class="mb-3 mt-3">
      <textarea name="comment" class="form-control" placeholder="Tulis komentar..." required></textarea>
      <button type="submit" name="submit_comment" class="btn btn-primary mt-2">Kirim</button>
    </form>


<?php
// --- Ambil semua komentar ---
$all_comments = $comments->fetch_all(MYSQLI_ASSOC);

// --- Fungsi tampil komentar ---
function tampilKomentar($all, $parent_id = null, $margin = 0) {
  $user_id = $_SESSION['user_id'];
  $role = $_SESSION['role'] ?? 'user';
  $post_owner_id = $GLOBALS['post']['user_id']; // pemilik posting

  foreach ($all as $row) {
    if ($row['parent_id'] == $parent_id) {

      echo "<div style='margin-left: {$margin}px; border-left: 2px solid #eee; padding-left:10px; margin-top:10px;'>";

      echo "<strong>{$row['username']}</strong> • <small>{$row['created_at']}</small>";

      // === LOGIKA HAK HAPUS ===
      if (
        $role === 'admin' ||                      // admin → boleh hapus semua
        $row['user_id'] == $user_id ||            // pemilik komentar → boleh hapus
        $post_owner_id == $user_id                // pemilik posting → boleh hapus komentar di postingannya
      ) {
        echo "<a href='singledetail.php?id={$GLOBALS['post_id']}&action=delete_comment&comment_id={$row['id']}'
                class='btn-delete-comment'
                onclick=\"return confirm('Yakin ingin menghapus komentar ini?');\">
                Hapus
              </a>";
      }

      echo "<br>";
      echo htmlspecialchars($row['comment']);

      // form balas komentar
      echo "<form method='post' class='ms-4 mb-2'>
              <input type='hidden' name='parent_id' value='{$row['id']}'>
              <textarea name='comment' placeholder='Balas komentar...' class='form-control' required></textarea>
              <button type='submit' name='submit_comment' class='btn btn-sm btn-secondary mt-1'>Balas</button>
            </form>";

      tampilKomentar($all, $row['id'], $margin + 30);

      echo "</div>";
    }
  }
}
?>

    <div class="comments mt-4">
      <?php tampilKomentar($all_comments); ?>
    </div>
  </div> <!-- /.container -->
</section>

<hr></hr>

<!-- KOMENTAR (static contoh, nanti bisa kita buat dinamis juga) -->
<!-- <section class="comments-section py-5 bg-white border-top">
  <div class="container">
    <h3 class="mb-4 fw-bold border-bottom pb-2">Komentar</h3>
    <p class="text-muted">Belum ada komentar untuk postingan ini.</p> -->

    <!-- Form komentar -->
    <!-- <div class="comment-form-wrap mt-5">
      <h4 class="mb-4 fw-bold border-bottom pb-2">Tinggalkan Komentar</h4>
      <form action="#" class="p-4 bg-light rounded shadow-sm">
        <div class="mb-3">
          <label for="message" class="form-label fw-semibold">Pesan</label>
          <textarea id="message" cols="30" rows="5" class="form-control" placeholder="Tulis komentar kamu di sini..."></textarea>
        </div>
        <div class="text-end">
          <button type="submit" class="btn btn-dark px-4">Post Comment</button>
        </div>
      </form>
    </div>
  </div> -->
<!-- </section> -->

<?php include "footeruser.php"; ?>

<!-- SCRIPTS -->
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/tiny-slider.js"></script>
<script src="js/flatpickr.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/glightbox.min.js"></script>
<script src="js/navbar.js"></script>
<script src="js/counter.js"></script>
<script src="js/custom.js"></script>

<script>
// Client-side search UI (AJAX) - shows title + pengirim and ensures dark-brown text on cards
document.addEventListener('DOMContentLoaded', function () {
  const mobileInput = document.getElementById('searchInputMobileTop');
  const desktopInput = document.getElementById('searchInputDesktop');
  const mobileForm = document.getElementById('searchFormMobile');
  const desktopForm = document.getElementById('searchFormDesktop');
  const section = document.getElementById('search-results-section');
  const container = document.getElementById('search-results-container');

  function bindInput(input) {
    if (!input) return;
    input.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        doSearch(input.value.trim());
      }
    });
  }

  // prevent default form submit to enable AJAX; allow normal GET when JS disabled
  [mobileForm, desktopForm].forEach(f => {
    if (!f) return;
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      const input = f.querySelector('input[name="search"]');
      if (input) doSearch(input.value.trim());
    });
  });

  bindInput(mobileInput);
  bindInput(desktopInput);

  function doSearch(keyword) {
    if (!keyword) {
      section.style.display = 'none';
      return;
    }
    fetch(`dashboarduser.php?ajax=1&search=${encodeURIComponent(keyword)}`)
      .then(resp => resp.json())
      .then(data => {
        if (!Array.isArray(data) || data.length === 0) {
          container.innerHTML = `<div class="col-12"><p class="search-no-results" style="color:#fff;">Tidak ada hasil untuk "<strong>${escapeHtml(keyword)}</strong>"</p></div>`;
        } else {
          container.innerHTML = data.map(post => {
            const img = post.image ? post.image : 'images/default.png';
            const title = escapeHtml(post.title || '');
            const desc = escapeHtml(post.deskripsi || '');
            const author = escapeHtml(post.username || 'Unknown');
            const date = post.created_at ? new Date(post.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' }) : '';
            // each result is a white card so dark-brown text is visible on page brown background
            return `<div class="col-md-4">
                      <div class="search-result-card">
                        <a href="singledetail.php?id=${encodeURIComponent(post.id)}" class="img-link d-block mb-2">
                          <img src="${img}" alt="${title}" class="img-fluid rounded">
                        </a>
                        <div class="search-card-title">${title}</div>
                        <div class="search-card-meta">By ${author} • ${escapeHtml(date)}</div>
                        <div class="search-card-desc">${desc}</div>
                      </div>
                    </div>`;
          }).join('');
        }
        section.style.display = 'block';
        // scroll to results
        window.scrollTo({ top: section.offsetTop - 80, behavior: "smooth" });
      })
      .catch(err => {
        console.error(err);
        container.innerHTML = `<div class="col-12"><p class="search-no-results">Terjadi kesalahan saat mencari.</p></div>`;
        section.style.display = 'block';
      });
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }
});
</script>

</body>
</html>

