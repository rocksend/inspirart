// js/main.js

// Generate Post Otomatis
const postContainer = document.getElementById("post-container");
posts.forEach(post => {
  const postHTML = `
    <div class="col-md-6 col-lg-3 mb-4">
      <div class="blog-entry">
        <a href="singledetail.html?id=${post.id}" class="img-link">
          <img src="${post.image}" alt="${post.title}" class="img-fluid rounded">
        </a>
        <span class="date">${post.date}</span>
        <h2><a href="singledetail.html?id=${post.id}">${post.title}</a></h2>
        <p>${post.desc}</p>
        <p><a href="singledetail.html?id=${post.id}" class="read-more">Continue Reading</a></p>
      </div>
    </div>`;
  postContainer.insertAdjacentHTML("beforeend", postHTML);
});

// Fitur Search
document.addEventListener('DOMContentLoaded', function() {
  const searchInputs = [
    document.getElementById('searchInputMobile'),
    document.getElementById('searchInputDesktop')
  ].filter(Boolean);

  searchInputs.forEach(input => {
    input.addEventListener('keypress', function(e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        const keyword = input.value.trim().toLowerCase();
        handleSearch(keyword);
      }
    });
  });

  function handleSearch(keyword) {
    const section = document.getElementById('search-results-section');
    const container = document.getElementById('search-results-container');

    if (keyword === "") {
      section.style.display = "none";
      return;
    }

    const results = posts.filter(post =>
      post.title.toLowerCase().includes(keyword)
    );

    if (results.length === 0) {
      container.innerHTML = `<p>Tidak ada hasil untuk "<strong>${keyword}</strong>"</p>`;
    } else {
      container.innerHTML = results.map(post => `
        <div class="col-md-4">
          <div class="blog-entry">
            <a href="singledetail.html?id=${post.id}" class="img-link">
              <img src="${post.image}" alt="${post.title}" class="img-fluid rounded">
            </a>
            <h5 class="mt-2"><a href="singledetail.html?id=${post.id}">${post.title}</a></h5>
          </div>
        </div>
      `).join('');
    }

    section.style.display = "block";
    window.scrollTo({ top: section.offsetTop - 80, behavior: "smooth" });
  }
});
