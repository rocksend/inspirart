// js/posts.js
const posts = [
  {
    id: "1",
    title: "Cara Lukis Motif Batik Jawa",
    date: "Sep. 30th, 2025",
    image: "images/javanese batik.jpg",
    desc: "Berikut ini cara untuk membuat lukisan motif batik jawa. Dalam seni tradisional ini, setiap pola batik memiliki makna filosofis tersendiri yang menggambarkan nilai."
  },
  {
    id: "2",
    title: "Projek Anak Sekolah Dasar",
    date: "Sep. 30th, 2025",
    image: "images/boneka.jpg",
    desc: "Anak perempuan bernama Laura membuat boneka lucu dari clay. Dengan kreativitas dan imajinasi, Laura menunjukkan bahwa seni dapat dimulai dari hal-hal kecil yang sederhana."
  },
  {
    id: "3",
    title: "Admin Raka Ngirim Fanartnya!",
    date: "Sep. 30th, 2025",
    image: "images/poster.jpg",
    desc: "Untuk mengisi kekosongan template, admin Raka mengirimkan fanartnya! Karya ini terinspirasi dari gaya pop art yang berani dengan warna kontras yang mencolok."
  },
  {
    id: "4",
    title: "Kerajinan di Kota Yogyakarta",
    date: "Sep. 30th, 2025",
    image: "images/miniatur sepeda.jpg",
    desc: "Yogyakarta dikenal dengan kekayaan seni dan kerajinannya. Salah satu yang menarik adalah miniatur sepeda buatan tangan yang mencerminkan ketelitian dan keindahan karya lokal."
  }
];
