<!-- /*
* Template Name: Blogy
* Template Author: Untree.co
* Template URI: https://untree.co/
* License: https://creativecommons.org/licenses/by/3.0/
*/ -->

<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">

	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap5" />

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">


	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

	<link rel="stylesheet" href="css/tiny-slider.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/glightbox.min.css">
	<link rel="stylesheet" href="css/style.css">

	<link rel="stylesheet" href="css/flatpickr.min.css">


	<title>Blogy &mdash; Free Bootstrap 5 Website Template by Untree.co</title>

<style>
.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}
</style>

</head>
<body>

	<div class="site-mobile-menu site-navbar-target">
		<div class="site-mobile-menu-header">
			<div class="site-mobile-menu-close">
				<span class="icofont-close js-menu-toggle"></span>
			</div>
		</div>
		<div class="site-mobile-menu-body"></div>
	</div>

	
	<!-- NAVBAR -->
  <nav class="site-nav">
    <div class="container">
      <div class="menu-bg-wrap">
        <div class="site-navigation">
          <div class="row g-0 align-items-center">
            <div class="col-2">
              <a href="dashboarduser.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
            </div>
            <div class="col-8 text-center">
              <form action="dashboarduser.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobileTop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form>

             <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                <li><a href="dashboarduser.php">Home</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="post.php">Post</a></li>
                <li><a href="category.php">Categories</a></li>
                <li class="active"><a href="aboutus.php">About Us</a></li>
			<ul>
            </div>
            <div class="col-2 text-end">
              <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                <span></span>
              </a>
               <!-- <form action="dashboarduser.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobile" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->

              <!-- <form action="dashboarduser.php" method="get" class="search-form d-none d-lg-inline-block">
                <input type="text" name="search" id="searchInputDesktop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>

	<div class="site-cover site-cover-sm same-height overlay single-page" style="background-image: url('https://i.pinimg.com/1200x/1d/c8/61/1dc8619487310884c9d631d689ece1e7.jpg');">
		<div class="container">
			<div class="row same-height justify-content-center">
				<div class="col-md-6">
					<div class="post-entry text-center">
						<h1 class="mb-4">About Us</h1>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="section sec-halfs py-0">
		<div class="container">
			<div class="half-content d-lg-flex align-items-stretch">
				<div class="img" style="background-image: url('https://i.pinimg.com/1200x/6d/b9/52/6db9525a29124d52e8b53e308ffa0751.jpg')" data-aos="fade-in" data-aos-delay="100">
					
				</div>
				<div class="text">
					<h2 class="heading text-primary mb-3">Dari Inspirasi Menjadi Karya</h2>
					<p class="mb-4"><b>InspirArt</b> adalah ruang digital tempat imajinasi dan kreativitas bertemu. Kami hadir untuk menginspirasi serta mendukung seniman dari berbagai latar belakang agar terus bereksperimen dan berkarya tanpa batas. Melalui konten yang edukatif dan inspiratif, InspirArt berupaya menjadi teman perjalanan bagi siapa pun yang mencintai dunia seni. ✨.</p>
				</div>
			</div>

			<div class="half-content d-lg-flex align-items-stretch">
				<div class="img order-md-2" style="background-image: url('https://i.pinimg.com/736x/ee/af/76/eeaf766d2be98bdb9302814de065237b.jpg')" data-aos="fade-in">
					
				</div>
				<div class="text">
					<h2 class="heading text-primary mb-3">Temukan Dunia Kreatifmu di InspirArt</h2>
					<p class="mb-4">Di InspirArt, kamu bisa menemukan berbagai artikel menarik seputar <b>lukisan, fotografi, mural, fashion design, craft, hingga arsitektur seni modern</b>. Setiap tulisan dikemas dengan ringan namun penuh makna — mulai dari teknik melukis tradisional, ulasan karya terkenal, hingga tren desain masa kini. Mari tumbuhkan semangat berkarya bersama kami di InspirArt — Where Imagination Meets Creation</p>
				</div>
			</div>
		</div>

	</div>

	<div class="section sec-features">
		<div class="container">
			<div class="row g-5">
				<div class="col-12 col-sm-6 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="0">
					<div class="feature d-flex">
						<span class="bi-bag-check-fill"></span>
						<div>
							<h3>Building your blog</h3>
							<p>Bagikan dan buatlah blog anda tentang art disini, bagikan emosimu melalui blog. </p>
						</div>
					</div>
				</div>
				<div class="col-12 col-sm-6 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="100">
					<div class="feature d-flex">
						<span class="bi-wallet-fill"></span>
						<div>
							<h3>Resources and insights</h3>
							<p>Sumber inspirasi dan insights yang dapat diakses.</p>
						</div>
					</div>
				</div>
				<div class="col-12 col-sm-6 col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="200">
					<div class="feature d-flex">
						<span class="bi-pie-chart-fill"></span>
						<div>
							<h3>Blog just for you</h3>
							<p>Blog ini untuk kalian pecinta seni. </p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div class="section">
		<div class="container">
			
			<div class="row mb-5">
				<div class="col-lg-5 mx-auto text-center" data-aos="fade-up">
					<h2 class="heading text-primary">Our Team</h2>
					<p>Tim Blogger Art. </p>
				</div>
			</div>

			<div class="row">
				<div class="col-lg-4 mb-4 text-center" data-aos="fade-up" data-aos-delay="0">
					<img src="images/foto raka.jpg" alt="Image" class="img-fluid w-50 rounded-circle mb-3">
					<h5 class="text-black">Muhammad Raka Bisma R.</h5>
					<p>Nim saya adalah 24051214036</p>
					<p>Saya Raka. Saya satu-satunya lelaki di kelompok ini.</p>
				</div>
				<div class="col-lg-4 mb-4 text-center" data-aos="fade-up" data-aos-delay="100">
					<img src="images/foto divia.jpg" alt="Image" class="img-fluid w-50 rounded-circle mb-3">
					<h5 class="text-black">Divia Indah Lestari</h5>
					<p>Nim saya adalah 24051214059</p>
					<p>Halo! nama saya Divia. Salam kenal. </p>
				</div>
				<div class="col-lg-4 mb-4 text-center" data-aos="fade-up" data-aos-delay="200">
					<img src="images/foto qolbi.jpg" alt="Image" class="img-fluid w-50 rounded-circle mb-3">
					<h5 class="text-black">Nur Qolbi Khoirunnisa</h5>
					<p>Nim saya adalah 24051214043</p>
					<p>Hi Semua! nama saya Qolbi ya.</p>
				</div>
			</div>

		</div>
	</div>



	<!-- <div class="section">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-7 mb-4 mb-lg-0">
					<img src="images/img_7_sq.jpg" alt="Image" class="img-fluid rounded
					">
				</div>
				<div class="col-lg-4 ps-lg-2">
					<div class="mb-5">
						<h2 class="text-black h4">Publishing platform for professional bloggers</h2>
						<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
					</div>
					<div class="d-flex mb-3 service-alt">
						<div>
							<span class="bi-wallet-fill me-4"></span>
						</div>
						<div>
							<h3>Building your blog</h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
						</div>
					</div>

					<div class="d-flex mb-3 service-alt">
						<div>
							<span class="bi-pie-chart-fill me-4"></span>
						</div>
						<div>
							<h3>Resources and insights</h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
						</div>
					</div>

					<div class="d-flex mb-3 service-alt">
						<div>
							<span class="bi-bag-check-fill me-4"></span>
						</div>
						<div>
							<h3>Blog just for you</h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
						</div>
					</div>

				</div>

			</div>
		</div>
	</div> -->

	<!-- FOOTER -->
	 <?php include "footeruser.php"; ?>

    <!-- Preloader -->
    <div id="overlayer"></div>
    <div class="loader">
    	<div class="spinner-border text-primary" role="status">
    		<span class="visually-hidden">Loading...</span>
    	</div>
    </div>


    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="js/tiny-slider.js"></script>

    <script src="js/flatpickr.min.js"></script>


    <script src="js/aos.js"></script>
    <script src="js/glightbox.min.js"></script>
    <script src="js/navbar.js"></script>
    <script src="js/counter.js"></script>
    <script src="js/custom.js"></script>

    
  </body>
  </html>
