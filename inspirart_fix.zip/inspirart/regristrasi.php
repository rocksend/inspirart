
<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include __DIR__ . "/config.php";

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = isset($_POST["username"]) ? trim($_POST["username"]) : '';
    $email = isset($_POST["email"]) ? trim($_POST["email"]) : '';
    $password = isset($_POST["password"]) ? trim($_POST["password"]) : '';

    // Validasi dasar
    if (!$username || !$email || !$password) {
        $error = "❌ Semua bidang harus diisi.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "❌ Email tidak valid.";
    } else {
        // Cek apakah username atau email sudah terdaftar
        $check = $conn->prepare("SELECT id FROM users WHERE email = ? OR username = ? LIMIT 1");
        if ($check) {
            $check->bind_param("ss", $email, $username);
            $check->execute();
            $check->store_result();
            if ($check->num_rows > 0) {
                $error = "❌ Username atau email sudah terdaftar.";
            }
            $check->close();
        } else {
            $error = "❌ Gagal memeriksa duplikat: " . $conn->error;
        }
    }

    // Bila valid, simpan
    if (!$error) {
        // NOTE: menyimpan password mentah (plaintext). TIDAK aman.
        // simpan langsung password tanpa hashing
        $password_stored = $password;

        // set role default 'user' (sesuaikan jika tabel punya kolom role)
        $role = 'user';

        // Masukkan kolom yang pasti ada: username,email,password,role
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role, created_at) VALUES (?, ?, ?, ?, NOW())");
        if ($stmt) {
            $stmt->bind_param("ssss", $username, $email, $password_stored, $role);
            if ($stmt->execute()) {
                // sukses -> redirect ke halaman index
                header("Location: index.php");
                exit;
            } else {
                $error = "❌ Gagal mendaftar: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "❌ Gagal menyiapkan pernyataan: " . $conn->error;
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="InspirART">
    <link rel="shortcut icon" href="favicon.png">

    <meta name="description" content="" />
    <meta name="keywords" content="bootstrap, bootstrap5" />

    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="css/tiny-slider.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/glightbox.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/flatpickr.min.css">

    <title>InspirART — Register</title>
<style>
.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}
</style>


</head>
<body>

  <!-- NAVBAR -->
  <nav class="site-nav">
    <div class="container">
      <div class="menu-bg-wrap">
        <div class="site-navigation">
          <div class="row g-0 align-items-center">
            <div class="col-2">
              <a href="dashboard.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
            </div>
            <div class="col-8 text-center">
              <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                <li class="active"><a href="###">Register</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="dashboarduser.php">Home</a></li>
                <li><a href="###">Categories</a></li>
                <li><a href="###">About Us</a></li>
              </ul>
            </div>
            <div class="col-2 text-end">
              <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                <span></span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>

<div class="site-cover site-cover-sm same-height overlay single-page" style="background-image: url('https://i.pinimg.com/1200x/1d/c8/61/1dc8619487310884c9d631d689ece1e7.jpg');">
		<div class="container">
			<div class="row same-height justify-content-center">
				<div class="col-md-6">
					<div class="post-entry text-center">
						<h1 class="mb-4">REGISTER</h1>
					</div>
				</div>
			</div>
		</div>
	</div>

<!-- Register Form Section -->
<div class="section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST" class="p-4 border rounded bg-light shadow">
                    <h3 class="text-center mb-4">Silahkan Isi Form</h3>

                    <!-- Tampilkan pesan error / sukses -->
                    <?php if ($error): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    <?php if ($message): ?>
                        <div class="alert alert-success"><?php echo $message; ?></div>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="text" id="username" name="username" class="form-control" placeholder="Masukkan username..." required value="<?php echo isset($username) ? htmlspecialchars($username) : ''; ?>">
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="Masukkan email..." required value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
                    </div>

                    <div class="mb-3">
                        <label for="password" class="form-label">Password</label>
                        <input type="password" id="password" name="password" class="form-control" placeholder="Masukkan password..." required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary" id="btnDaftar">Daftar</button>
                    </div>

                    <p class="text-center mt-3">Sudah punya akun? <a href="index.php">login</a></p>
                </form>
            </div>
        </div>
    </div>
</div> <!-- /.section -->

<!-- FOOTER -->
<?php include "footeruser.php"; ?>

<!-- Scripts -->
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/tiny-slider.js"></script>
<script src="js/flatpickr.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/glightbox.min.js"></script>
<script src="js/navbar.js"></script>
<script src="js/counter.js"></script>
<script src="js/custom.js"></script>
</body>
</html>