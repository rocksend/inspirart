-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2025 at 04:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inspirart_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--


--
-- Dumping data for table `comments`
--

INSERT IGNORE INTO `comments` (`id`, `post_id`, `user_id`, `parent_id`, `comment`, `created_at`) VALUES
(1, 2, 3, NULL, 'artikelnya sangat bagus', '2025-11-05 19:25:54'),
(2, 2, 3, 1, 'iya betul, aku setuju', '2025-11-06 01:32:48'),
(3, 1, 3, NULL, 'halo', '2025-11-06 02:18:44');

COMMIT;

