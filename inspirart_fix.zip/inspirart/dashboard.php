<?php
include __DIR__ . '/config.php';
// simple helper
function tableExists($conn, $name) {
    $res = $conn->query("SHOW TABLES LIKE '".$conn->real_escape_string($name)."'");
    return $res && $res->num_rows > 0;
}
function fetchPairs($conn, $sql) {
    $rows = [];
    $res = $conn->query($sql);
    if ($res) {
        while ($r = $res->fetch_assoc()) $rows[] = $r;
    }
    return $rows;
}

// totals
$totals = [
    'users' => 0,
    'posts' => 0,
    'visits' => 0,
];

if ($conn) {
    if (tableExists($conn,'users')) {
        $r = $conn->query("SELECT COUNT(*) AS c FROM users");
        $totals['users'] = $r ? (int)$r->fetch_assoc()['c'] : 0;
    }
    if (tableExists($conn,'posts')) {
        $r = $conn->query("SELECT COUNT(*) AS c FROM posts");
        $totals['posts'] = $r ? (int)$r->fetch_assoc()['c'] : 0;
    }
    // visits table may be named visits or page_views
    if (tableExists($conn,'visits')) {
        $r = $conn->query("SELECT COUNT(*) AS c FROM visits");
        $totals['visits'] = $r ? (int)$r->fetch_assoc()['c'] : 0;
    } elseif (tableExists($conn,'page_views')) {
        $r = $conn->query("SELECT COUNT(*) AS c FROM page_views");
        $totals['visits'] = $r ? (int)$r->fetch_assoc()['c'] : 0;
    }
}

// time series (last 30 days) for charts
$days = 30;
$labels = [];
$usersSeries = [];
$postsSeries = [];
$visitsSeries = [];

// build date labels (last $days)
for ($i = $days-1; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $labels[] = $d;
    $usersSeries[$d] = 0;
    $postsSeries[$d] = 0;
    $visitsSeries[$d] = 0;
}

// fill users by date
if ($conn && tableExists($conn,'users')) {
    $sql = "SELECT DATE(created_at) AS d, COUNT(*) AS c FROM users
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL {$days} DAY)
            GROUP BY DATE(created_at)";
    $rows = fetchPairs($conn, $sql);
    foreach ($rows as $r) if (isset($usersSeries[$r['d']])) $usersSeries[$r['d']] = (int)$r['c'];
}

// fill posts by date
if ($conn && tableExists($conn,'posts')) {
    $sql = "SELECT DATE(created_at) AS d, COUNT(*) AS c FROM posts
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL {$days} DAY)
            GROUP BY DATE(created_at)";
    $rows = fetchPairs($conn, $sql);
    foreach ($rows as $r) if (isset($postsSeries[$r['d']])) $postsSeries[$r['d']] = (int)$r['c'];
}

// fill visits by date (if table exists)
$visTable = null;
if ($conn && tableExists($conn,'visits')) $visTable = 'visits';
elseif ($conn && tableExists($conn,'page_views')) $visTable = 'page_views';

if ($conn && $visTable) {
    $sql = "SELECT DATE(created_at) AS d, COUNT(*) AS c FROM {$visTable}
            WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL {$days} DAY)
            GROUP BY DATE(created_at)";
    $rows = fetchPairs($conn, $sql);
    foreach ($rows as $r) if (isset($visitsSeries[$r['d']])) $visitsSeries[$r['d']] = (int)$r['c'];
}

// latest users and posts (simple lists)
$latestUsers = [];
$latestPosts = [];
if ($conn && tableExists($conn,'users')) {
    $latestUsers = fetchPairs($conn, "SELECT id, username, email, created_at FROM users ORDER BY created_at DESC LIMIT 10");
}
if ($conn && tableExists($conn,'posts')) {
    $latestPosts = fetchPairs($conn, "SELECT id, title, created_at FROM posts ORDER BY created_at DESC LIMIT 10");
}

// prepare arrays for chart.js
$labelsJs = json_encode(array_values($labels));
$usersJs = json_encode(array_values($usersSeries));
$postsJs = json_encode(array_values($postsSeries));
$visitsJs = json_encode(array_values($visitsSeries));
?>

<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta name="author" content="InspirARTMedia.co">
 <link rel="shortcut icon" href="favicon.png">
 <meta name="description" content="" />
 <meta name="keywords" content="art, blog, gallery, inspirart" />
 <link rel="preconnect" href="https://fonts.googleapis.com">
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="fonts/icomoon/style.css">
 <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
 <link rel="stylesheet" href="css/tiny-slider.css">
 <link rel="stylesheet" href="css/aos.css">
 <link rel="stylesheet" href="css/glightbox.min.css">
 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="css/flatpickr.min.css">
 <title>InspirART - Art Blog Platform</title>

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    body {font-family: Arial, sans-serif; padding:0px; background:#FEFAE0;}
    .card {border-radius:8px;}
    .stat {font-size:1.5rem; font-weight:600;}
    .small-muted {color:#6c757d; font-size:.85rem;}
    .chart-wrap {height:300px;}
    table td, table th {vertical-align:middle;}
/* .site-nav .container-fluid { padding-left: 0; padding-right: 0; max-width: 100%; } */
    .menu-bg-wrap { width: 100%; }
    /* .site-navigation { width: 100%; } */

    h2 {
      font-size: small;
      padding-top: 5px;
    }

    nav ul.pagination { display:flex; justify-content:center; gap:10px; margin-top:30px; }
nav ul.pagination li.page-item { list-style:none; }
nav ul.pagination li.page-item a.page-link { border:1px solid #c5a37a; border-radius:50%; width:40px; height:40px; display:flex; align-items:center; justify-content:center; color:#8b4513; background:#fffaf0; font-weight:600; font-size:16px; transition:all .3s; text-decoration:none; }
nav ul.pagination li.page-item.active a.page-link { background:#8b4513; color:#fff; border-color:#8b4513; }
nav ul.pagination li.page-item a.page-link:hover { background:#a05a2c; color:#fff; }
nav ul.pagination li.page-item.disabled a.page-link { opacity:.4; cursor:not-allowed; }
nav ul.pagination li.page-item:first-child a.page-link, nav ul.pagination li.page-item:last-child a.page-link { width:auto; padding:0 15px; border-radius:25px; font-size:15px; }

/* Search results section styling */
#search-results-section { display:none; padding-top:30px; padding-bottom:30px; background:#6b4b3a; } /* brown background */
#search-results-container .blog-entry img { max-height:160px; object-fit:cover; width:100%; border-radius:6px; }
.search-no-results { color:#6c757d; padding:40px 0; text-align:center; }

/* Styling for search result card text: dark brown */
.search-card-title { font-size:18px; font-weight:700; margin-top:10px; color:#3e2723; } /* dark brown */
.search-card-meta { font-size:13px; color:#5d4037; margin-bottom:8px; } /* slightly lighter brown */
.search-card-desc { color:#5d4037; font-size:14px; }

/* card container to ensure good contrast on brown background */
.search-result-card { background:#ffffff; border-radius:10px; padding:12px; box-shadow:0 6px 18px rgba(0,0,0,0.08); height:100%; }

/* fallback: fixed */

.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}


.post-thumb {
  width: 100%;
  height: 220px;          /* SAMAKAN TINGGI */
  object-fit: cover;     /* POTONG otomatis, proporsional */
  object-position: center;
}

.postdesc {
  font-size: 14px;
  color: #6c757d;

  display: -webkit-box;
  -webkit-line-clamp: 3;     /* JUMLAH BARIS */
  -webkit-box-orient: vertical;
  overflow: hidden;

  line-height: 1.5em;
  min-height: 4.5em;         /* 3 baris x line-height */
}

/* sesuaikan nilai 72px dengan tinggi navbar sesungguhnya
body { padding-top: 72px; } */

  </style>
</head>
<body>

<!-- NAVBAR -->
  <nav class="site-nav">
    <div class="container">
      <div class="menu-bg-wrap">
        <div class="site-navigation">
          <div class="row g-0 align-items-center">
            <div class="col-2">
              <a href="dashboarduser.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
            </div>
            <div class="col-8 text-center">
              <form action="dashboarduser.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobileTop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form>

              <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                <li class="active"><a href="dashboard.php">Dashboard</a></li>
                <li><a href="profiladmin.php">Profile</a></li>
                <li><a href="indexadmin.php">Post</a></li>
                <li><a href="categoryadmin.php">Categories</a></li>
                <li><a href="about.php">About Us</a></li>
              </ul>
            </div>
            <div class="col-2 text-end">
              <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                <span></span>
              </a>
               <!-- <form action="dashboarduser.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobile" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->

              <!-- <form action="dashboarduser.php" method="get" class="search-form d-none d-lg-inline-block">
                <input type="text" name="search" id="searchInputDesktop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
      <h2>Admin Dashboard</h2>
      <small class="small-muted">Generated: <?php echo date('Y-m-d H:i:s'); ?></small>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-md-4">
        <div class="card p-3">
          <div class="small-muted">Total Users</div>
          <div class="stat"><?php echo (int)$totals['users']; ?></div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-3">
          <div class="small-muted">Total Posts</div>
          <div class="stat"><?php echo (int)$totals['posts']; ?></div>
        </div>
      </div>
      <div class="col-md-4">
        <div class="card p-3">
          <div class="small-muted">Total Visits</div>
          <div class="stat"><?php echo (int)$totals['visits']; ?></div>
        </div>
      </div>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-lg-6">
        <div class="card p-3">
          <h5 class="mb-3">User Registrations (last <?php echo $days; ?> days)</h5>
          <div class="chart-wrap"><canvas id="usersChart"></canvas></div>
        </div>
      </div>
      <div class="col-lg-6">
        <div class="card p-3">
          <h5 class="mb-3">Posts Created (last <?php echo $days; ?> days)</h5>
          <div class="chart-wrap"><canvas id="postsChart"></canvas></div>
        </div>
      </div>
    </div>

    <div class="row g-3 mb-4">
      <div class="col-lg-12">
        <div class="card p-3">
          <h5 class="mb-3">Site Visits (last <?php echo $days; ?> days)</h5>
          <div class="chart-wrap"><canvas id="visitsChart"></canvas></div>
        </div>
      </div>
    </div>

    <div class="row g-3">
      <div class="col-lg-6">
        <div class="card p-3">
          <h6>Latest Users</h6>
          <div class="table-responsive">
            <table class="table table-sm">
              <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Created</th></tr></thead>
              <tbody>
                <?php if (empty($latestUsers)): ?>
                  <tr><td colspan="4" class="text-center small-muted">No users found</td></tr>
                <?php else: foreach ($latestUsers as $u): ?>
                  <tr>
                    <td><?php echo (int)$u['id']; ?></td>
                    <td><?php echo htmlspecialchars($u['username']); ?></td>
                    <td><?php echo htmlspecialchars($u['email']); ?></td>
                    <td><?php echo htmlspecialchars($u['created_at']); ?></td>
                  </tr>
                <?php endforeach; endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div class="col-lg-6">
        <div class="card p-3">
          <h6>Latest Posts</h6>
          <div class="table-responsive">
            <table class="table table-sm">
              <thead><tr><th>ID</th><th>Title</th><th>Created</th></tr></thead>
              <tbody>
                <?php if (empty($latestPosts)): ?>
                  <tr><td colspan="3" class="text-center small-muted">No posts found</td></tr>
                <?php else: foreach ($latestPosts as $p): ?>
                  <tr>
                    <td><?php echo (int)$p['id']; ?></td>
                    <td><?php echo htmlspecialchars($p['title']); ?></td>
                    <td><?php echo htmlspecialchars($p['created_at']); ?></td>
                  </tr>
                <?php endforeach; endif; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>

  </div>
<br><br>

<!-- FOOTER -->
  <?php include "footeradmin.php"; ?>

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    const labels = <?php echo $labelsJs; ?>;
    const usersData = <?php echo $usersJs; ?>;
    const postsData = <?php echo $postsJs; ?>;
    const visitsData = <?php echo $visitsJs; ?>;

    function makeLine(id, label, data, color) {
      const ctx = document.getElementById(id).getContext('2d');
      return new Chart(ctx, {
        type: 'line',
        data: { labels: labels, datasets: [{ label: label, data: data, borderColor: color, backgroundColor: color+'33', fill: true, tension:0.2 }]},
        options: { responsive:true, plugins:{legend:{display:false}}, scales:{ x:{display:true}, y:{beginAtZero:true, ticks:{precision:0}}}}
      });
    }

    makeLine('usersChart', 'Registrations', usersData, '#0d6efd');
    makeLine('postsChart', 'Posts', postsData, '#198754');
    makeLine('visitsChart', 'Visits', visitsData, '#dc3545');
  </script>
</body>
</html>