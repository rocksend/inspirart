<?php
session_start();
include __DIR__ . '/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$message = '';
$error = '';

// handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['profile_img'])) {
    $file = $_FILES['profile_img'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = 'Gagal mengunggah file.';
    } else {
        $maxSize = 2 * 1024 * 1024; // 2MB
        if ($file['size'] > $maxSize) {
            $error = 'File terlalu besar (max 2MB).';
        } else {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mime = finfo_file($finfo, $file['tmp_name']);
            finfo_close($finfo);
            $allowed = ['image/jpeg' => 'jpg', 'image/pjpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif'];
            if (!array_key_exists($mime, $allowed)) {
                $error = 'Format file tidak diperbolehkan. Gunakan JPG, PNG, atau GIF.';
            } else {
                $ext = $allowed[$mime];
                $targetDir = __DIR__ . '/uploads/profiles/';
                if (!is_dir($targetDir)) {
                    mkdir($targetDir, 0755, true);
                }
                $newName = 'user_' . $user_id . '_' . time() . '.' . $ext;
                $targetPath = $targetDir . $newName;
                if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
                    $error = 'Gagal memindahkan file.';
                } else {
                    // simpan path relatif ke DB
                    $relPath = 'uploads/profiles/' . $newName;

                    // ambil current image untuk possible cleanup
                    $oldImg = '';
                    $s = $conn->prepare("SELECT profile_img FROM users WHERE id = ? LIMIT 1");
                    if ($s) {
                        $s->bind_param('i', $user_id);
                        $s->execute();
                        $s->bind_result($oldImg);
                        $s->fetch();
                        $s->close();
                    }

                    $u = $conn->prepare("UPDATE users SET profile_img = ? WHERE id = ?");
                    if ($u) {
                        $u->bind_param('si', $relPath, $user_id);
                        if ($u->execute()) {
                            // update session value
                            $_SESSION['profile_img'] = $relPath;
                            $message = 'Foto profil berhasil diperbarui.';
                            // hapus file lama jika bukan default dan ada
                            if ($oldImg && strpos($oldImg, 'default') === false && file_exists(__DIR__ . '/' . $oldImg)) {
                                @unlink(__DIR__ . '/' . $oldImg);
                            }
                        } else {
                            $error = 'Gagal menyimpan perubahan ke database: ' . $u->error;
                            // hapus file baru jika gagal DB
                            @unlink($targetPath);
                        }
                        $u->close();
                    } else {
                        $error = 'Gagal menyiapkan query: ' . $conn->error;
                        @unlink($targetPath);
                    }
                }
            }
        }
    }
    // redirect untuk menghindari resubmit form
    if ($message && !$error) {
        header('Location: profile.php?updated=1');
        exit;
    }
}

// ambil data user
$stmt = $conn->prepare("SELECT id, username, email, profile_img, created_at FROM users WHERE id = ? LIMIT 1");
$user = null;
if ($stmt) {
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    if (method_exists($stmt, 'get_result')) {
        $res = $stmt->get_result();
        $user = $res ? $res->fetch_assoc() : null;
    } else {
        $stmt->bind_result($id, $username, $email, $profile_img, $created_at);
        if ($stmt->fetch()) {
            $user = [
                'id' => $id,
                'username' => $username,
                'email' => $email,
                'profile_img' => $profile_img,
                'created_at' => $created_at
            ];
        }
    }
    $stmt->close();
}

$displayImg = 'images/person_1.jpg';
if (!empty($user['profile_img']) && file_exists(__DIR__ . '/' . $user['profile_img'])) {
    $displayImg = $user['profile_img'];
} elseif (!empty($user['profile_img'])) {
    // jika path ada tapi file tidak ditemukan, pakai URL jika profile_img adalah URL
    if (filter_var($user['profile_img'], FILTER_VALIDATE_URL)) {
        $displayImg = $user['profile_img'];
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="fonts/icomoon/style.css">
 <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
 <link rel="stylesheet" href="css/tiny-slider.css">
 <link rel="stylesheet" href="css/aos.css">
 <link rel="stylesheet" href="css/glightbox.min.css">
 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="css/flatpickr.min.css">
    <title>Profil Saya — InspirART</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">


    <style>
.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}

    </style>
</head>
<body>

 <!-- NAVBAR -->
  <nav class="site-nav">
    <div class="container">
      <div class="menu-bg-wrap">
        <div class="site-navigation">
          <div class="row g-0 align-items-center">
            <div class="col-2">
              <a href="dashboard.php" class="logo m-0 float-start">InspirART<span class="text-primary">.</span></a>
            </div>
            <div class="col-8 text-center">
              <form action="dashboard.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobileTop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form>

              <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li class="active"><a href="profiladmin.php">Profile</a></li>
                <li><a href="indexadmin.php">Post</a></li>
                <li><a href="categoryadmin.php">Categories</a></li>
                <li><a href="about.php">About Us</a></li>
              </ul>
            </div>
            <div class="col-2 text-end">
              <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                <span></span>
              </a>
               <!-- <form action="dashboard.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobile" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->

              <!-- <form action="dashboard.php" method="get" class="search-form d-none d-lg-inline-block">
                <input type="text" name="search" id="searchInputDesktop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>

<div class="site-cover site-cover-sm same-height overlay single-page" style="background-image: url('https://i.pinimg.com/1200x/1d/c8/61/1dc8619487310884c9d631d689ece1e7.jpg');">
		<div class="container">
			<div class="row same-height justify-content-center">
				<div class="col-md-6">
					<div class="post-entry text-center">
						<h1 class="mb-4">PROFILE</h1>
					</div>
				</div>
			</div>
		</div>
	</div>

<div class="section">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <?php if (isset($_GET['updated'])): ?>
                    <div class="alert alert-success">Foto profil berhasil diperbarui.</div>
                <?php endif; ?>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <?php if ($message): ?>
                    <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>

                <div class="card shadow p-4">
                    <div class="text-center">
                        <img src="<?php echo htmlspecialchars($displayImg, ENT_QUOTES); ?>" alt="Foto Profil" class="rounded-circle mb-3" width="120">
                        <h3 class="mb-0"><?php echo htmlspecialchars($user['username'] ?? ''); ?></h3>
                        <p class="text-muted">@<?php echo htmlspecialchars($user['username'] ?? ''); ?></p>
                    </div>

                    <hr>

                    <div class="mb-3"><strong>Email:</strong> <?php echo htmlspecialchars($user['email'] ?? ''); ?></div>
                    <div class="mb-3"><strong>Tanggal Bergabung:</strong> <?php echo !empty($user['created_at']) ? date('d M Y', strtotime($user['created_at'])) : ''; ?></div>

                    <form action="profile.php" method="post" enctype="multipart/form-data" class="mt-4">
                        <div class="mb-3">
                            <label for="profile_img" class="form-label">Ganti Foto Profil (JPG/PNG/GIF, max 2MB)</label>
                            <input type="file" id="profile_img" name="profile_img" class="form-control" accept="image/*" required>
                        </div>
                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary">Unggah</button>
                            <a href="index.php" class="btn btn-danger">Logout</a>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- FOOTER -->
<?php include "footeradmin.php"; ?>

<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/custom.js"></script>
</body>
</html>