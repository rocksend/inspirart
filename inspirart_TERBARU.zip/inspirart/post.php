<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include __DIR__ . "/config.php";

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

	if (!isset($_SESSION['user_id'])) {
        die("Anda harus login terlebih dahulu.");
	}

    $title = isset($_POST["title"]) ? trim($_POST["title"]) : '';
    $caption = isset($_POST["caption"]) ? trim($_POST["caption"]) : '';
    $category_id = isset($_POST["category"]) ? trim($_POST["category"]) : '';
    $deskripsi = isset($_POST["deskripsi"]) ? trim($_POST["deskripsi"]) : '';
    $user_id = $_SESSION['user_id'];

    $imagePath = "";
    if (!empty($_FILES["media"]["name"])) {
        $targetDir = __DIR__ . "/uploads/";
        if (!is_dir($targetDir)) {
            if (!mkdir($targetDir, 0777, true)) {
                $error = "Gagal membuat folder upload. Cek permission.";
            }
        }

        if (!$error) {
            $fileName = time() . "_" . preg_replace('/[^a-zA-Z0-9._-]/', '_', basename($_FILES["media"]["name"]));
            $targetFile = $targetDir . $fileName;
            $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
            $allowed = ["jpg", "jpeg", "png", "gif"];

            if (in_array($imageFileType, $allowed)) {
                if (move_uploaded_file($_FILES["media"]["tmp_name"], $targetFile)) {
                    $imagePath = "uploads/" . $fileName;
                } else {
                    $error = "❌ Gagal mengunggah gambar. (move_uploaded_file gagal)";
                }
            } else {
                $error = "❌ Hanya file JPG, PNG, dan GIF yang diperbolehkan.";
            }
        }
    } else {
        $error = "❌ Silakan pilih gambar untuk diunggah.";
    }

    // Simpan ke database jika valid
    if (!$error) {
        if ($title && $deskripsi && $imagePath && $category_id) {
            // content bisa diisi dari caption atau deskripsi
            $content = $caption ?: $deskripsi;

            $stmt = $conn->prepare("INSERT INTO posts (user_id, category_id, title, image, deskripsi, content, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");

            if ($stmt) {
                $stmt->bind_param("iissss", $user_id, $category_id, $title, $imagePath, $deskripsi, $content);
                if ($stmt->execute()) {
                    $message = "✅ Postingan berhasil diupload!";
                } else {
                    $error = "❌ Gagal menyimpan ke database: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error = "❌ Prepare statement gagal: " . $conn->error;
            }
        } else {
            $error = "❌ Judul, kategori, deskripsi, dan gambar wajib diisi.";
        }
    }
}
?>


<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="author" content="InspirARTMedia.co">
	<link rel="shortcut icon" href="favicon.png">
	<meta name="deskripsi" content="">
	<meta name="keywords" content="art, blog, inspirart, upload">

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="fonts/icomoon/style.css">
	<link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">

	<!-- Pastikan Bootstrap dimuat (template-mu memakai kelas bootstrap) -->
	<link rel="stylesheet" href="css/bootstrap.min.css">

	<link rel="stylesheet" href="css/tiny-slider.css">
	<link rel="stylesheet" href="css/aos.css">
	<link rel="stylesheet" href="css/glightbox.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/flatpickr.min.css">

	<title>InspirART — Create Post</title>

	<!-- STYLE SEMENTARA: Pastikan form terlihat (hapus jika style.css sudah benar) -->
	<style>
		/* Jika form elemen jadi "invisible" karena warna, paksa warna agar terlihat */
		body { color: #222; }
		.card .form-control { background: #fff; color: #222; border: 1px solid #ddd; }
		.card { background: #fff; }
		.alert { margin-top: 12px; }

		.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}
	</style>
</head>

<body>
	<nav class="site-nav">
		<div class="container">
			<div class="menu-bg-wrap">
				<div class="site-navigation">
					<div class="row g-0 align-items-center">
						<div class="col-2">
							<a href="dashboarduser.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
						</div>
						<div class="col-8 text-center">
							<ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
								<li><a href="dashboarduser.php">Home</a></li>
								<li><a href="profile.php">Profile</a></li>
								<li class="active"><a href="post.php">Post</a></li>
								<li><a href="category.php">Categories</a></li>
								<li><a href="aboutus.php">About Us</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</nav>

	<div class="site-cover site-cover-sm same-height overlay single-page" style="background-image: url('https://i.pinimg.com/1200x/1d/c8/61/1dc8619487310884c9d631d689ece1e7.jpg');">
		<div class="container">
			<div class="row same-height justify-content-center">
				<div class="col-md-6">
					<div class="post-entry text-center">
						<h1 class="mb-4">CREATE A POST</h1>
						<p class="text-white-50" data-aos="fade-up" data-aos-delay="100">Bagikan Postinganmu Kepada Dunia</p>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8" data-aos="fade-up" data-aos-delay="200">
					<div class="card shadow p-4">
						<h3 class="mb-4 text-center">Upload Postingan Baru</h3>

						<?php if (!empty($message)): ?>
							<div class="alert alert-success text-center"><?php echo $message; ?></div>
						<?php endif; ?>

						<?php if (!empty($error)): ?>
							<div class="alert alert-danger text-center"><?php echo $error; ?></div>
						<?php endif; ?>

						<form action="post.php" method="post" enctype="multipart/form-data">
							<div class="mb-3">
								<label for="media" class="form-label">Upload Media (Gambar/Foto)</label>
								<input type="file" class="form-control" id="media" name="media" accept="image/*" required>
							</div>

							<div class="mb-3">
								<label for="title" class="form-label">Judul</label>
								<input type="text" class="form-control" id="title" name="title" placeholder="Tulis judul..." required>
							</div>

							<div class="mb-3">
								<label for="caption" class="form-label">Caption</label>
								<input type="text" class="form-control" id="caption" name="caption" placeholder="Tulis caption singkat...">
							</div>

							<div class="mb-3">
    <label for="category" class="form-label">Kategori</label>
    <select class="form-select" id="category" name="category" required>
        <option value="" disabled selected>Pilih kategori...</option>
        <option value="1">Fashion Designs</option>
        <option value="2">Architecture</option>
        <option value="3">Mural</option>
        <option value="4">Grafitti</option>
        <option value="5">Craft</option>
         <option value="6">Floral</option>
          <option value="7">Photography</option>
           <option value="8">Painting</option>
    </select>
</div>


							<div class="mb-3">
								<label for="deskripsi" class="form-label">Deskripsi</label>
								<textarea id="deskripsi" name="deskripsi" rows="5" class="form-control" placeholder="Tuliskan deskripsi..."></textarea>
							</div>

							<div class="text-center">
								<button type="submit" class="btn btn-primary px-4">Upload</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>

  <!-- FOOTER -->
	<?php include "footeruser.php"; ?>

	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/tiny-slider.js"></script>
	<script src="js/flatpickr.min.js"></script>
	<script src="js/aos.js"></script>
	<script src="js/glightbox.min.js"></script>
	<script src="js/navbar.js"></script>
	<script src="js/counter.js"></script>
	<script src="js/custom.js"></script>
</body>
</html>