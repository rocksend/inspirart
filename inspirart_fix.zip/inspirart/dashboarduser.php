<?php
include "config.php";
$ip = $_SERVER['REMOTE_ADDR'];
$ua = $_SERVER['HTTP_USER_AGENT'];

$stmt = $conn->prepare("INSERT INTO visits (ip_address, user_agent) VALUES (?, ?)");
$stmt->bind_param("ss", $ip, $ua);
$stmt->execute();

// Pagination & sanitasi
$limit = 6; // per halaman
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) $page = 1;
$start = ($page - 1) * $limit;

// Raw search keyword
$search_raw = isset($_GET['search']) ? trim($_GET['search']) : '';

// --- AJAX search endpoint (returns JSON) ---
if (isset($_GET['ajax']) && $_GET['ajax'] == '1') {
    header('Content-Type: application/json; charset=utf-8');
    $kw = $search_raw;
    $rows = [];
    if ($kw !== '') {
        $like = "%{$kw}%";
        // ambil username juga supaya hasil menampilkan pengirim
        $stmt = $conn->prepare("
            SELECT p.id, p.title, p.image, p.deskripsi, p.created_at, u.username
            FROM posts p
            LEFT JOIN users u ON p.user_id = u.id
            WHERE p.title LIKE ? OR p.deskripsi LIKE ?
            ORDER BY p.created_at DESC
            LIMIT 50
        ");
        $stmt->bind_param("ss", $like, $like);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($r = $res->fetch_assoc()) {
            $rows[] = $r;
        }
        $stmt->close();
    }
    echo json_encode($rows);
    exit;
}

// Server-side search for main listing (kept as fallback)
if ($search_raw !== '') {
    $like = "%{$search_raw}%";

    // Hitung total hasil (prepared)
    $stmt_total = $conn->prepare("SELECT COUNT(*) AS total FROM posts WHERE title LIKE ? OR deskripsi LIKE ?");
    $stmt_total->bind_param("ss", $like, $like);
    $stmt_total->execute();
    $total_result = $stmt_total->get_result()->fetch_assoc();
    $stmt_total->close();

    // Ambil data postingan sesuai pencarian (prepared)
    $stmt = $conn->prepare("SELECT * FROM posts WHERE title LIKE ? OR deskripsi LIKE ? ORDER BY created_at DESC LIMIT ?, ?");
    $stmt->bind_param("ssii", $like, $like, $start, $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

} else {
    // Jika tidak ada pencarian
    $sql_total = "SELECT COUNT(*) AS total FROM posts";
    $total_result = $conn->query($sql_total)->fetch_assoc();

    // Ambil semua data postingan
    $sql = "SELECT * FROM posts ORDER BY created_at DESC LIMIT $start, $limit";
    $result = $conn->query($sql);
}

$total_pages = max(1, ceil($total_result['total'] / $limit));

// === Ambil Top 5 berdasarkan jumlah likes untuk BAGIAN POPULER ===
$top5 = [];
$topStmt = $conn->prepare("
    SELECT p.*, COALESCE(l.cnt,0) AS like_count, u.username, u.profile_img
    FROM posts p
    LEFT JOIN (
      SELECT post_id, COUNT(*) AS cnt FROM likes GROUP BY post_id
    ) l ON p.id = l.post_id
    LEFT JOIN users u ON p.user_id = u.id
    ORDER BY like_count DESC, p.created_at DESC
    LIMIT 5
");
if ($topStmt) {
    $topStmt->execute();
    $resTop = $topStmt->get_result();
    while ($r = $resTop->fetch_assoc()) {
        $top5[] = $r;
    }
    $topStmt->close();
}
?>
<!doctype html>
<html lang="en">
<head>
 <meta name="viewport" content="width=device-width, initial-scale=1">
 <meta name="author" content="InspirARTMedia.co">
 <link rel="shortcut icon" href="favicon.png">
 <meta name="description" content="" />
 <meta name="keywords" content="art, blog, gallery, inspirart" />
 <link rel="preconnect" href="https://fonts.googleapis.com">
 <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
 <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="fonts/icomoon/style.css">
 <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
 <link rel="stylesheet" href="css/tiny-slider.css">
 <link rel="stylesheet" href="css/aos.css">
 <link rel="stylesheet" href="css/glightbox.min.css">
 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="css/flatpickr.min.css">
 <title>InspirART - Art Blog Platform</title>
 <style>
nav ul.pagination { display:flex; justify-content:center; gap:10px; margin-top:30px; }
nav ul.pagination li.page-item { list-style:none; }
nav ul.pagination li.page-item a.page-link { border:1px solid #c5a37a; border-radius:50%; width:40px; height:40px; display:flex; align-items:center; justify-content:center; color:#8b4513; background:#fffaf0; font-weight:600; font-size:16px; transition:all .3s; text-decoration:none; }
nav ul.pagination li.page-item.active a.page-link { background:#8b4513; color:#fff; border-color:#8b4513; }
nav ul.pagination li.page-item a.page-link:hover { background:#a05a2c; color:#fff; }
nav ul.pagination li.page-item.disabled a.page-link { opacity:.4; cursor:not-allowed; }
nav ul.pagination li.page-item:first-child a.page-link, nav ul.pagination li.page-item:last-child a.page-link { width:auto; padding:0 15px; border-radius:25px; font-size:15px; }

/* Search results section styling */
#search-results-section { display:none; padding-top:30px; padding-bottom:30px; background:#6b4b3a; } /* brown background */
#search-results-container .blog-entry img { max-height:160px; object-fit:cover; width:100%; border-radius:6px; }
.search-no-results { color:#6c757d; padding:40px 0; text-align:center; }

/* Styling for search result card text: dark brown */
.search-card-title { font-size:18px; font-weight:700; margin-top:10px; color:#3e2723; } /* dark brown */
.search-card-meta { font-size:13px; color:#5d4037; margin-bottom:8px; } /* slightly lighter brown */
.search-card-desc { color:#5d4037; font-size:14px; }

/* card container to ensure good contrast on brown background */
.search-result-card { background:#ffffff; border-radius:10px; padding:12px; box-shadow:0 6px 18px rgba(0,0,0,0.08); height:100%; }

/* fallback: fixed */

.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}


.post-thumb {
  width: 100%;
  height: 220px;          /* SAMAKAN TINGGI */
  object-fit: cover;     /* POTONG otomatis, proporsional */
  object-position: center;
}

.postdesc {
  font-size: 14px;
  color: #6c757d;

  display: -webkit-box;
  -webkit-line-clamp: 3;     /* JUMLAH BARIS */
  -webkit-box-orient: vertical;
  overflow: hidden;

  line-height: 1.5em;
  min-height: 4.5em;         /* 3 baris x line-height */
}

/* sesuaikan nilai 72px dengan tinggi navbar sesungguhnya
body { padding-top: 72px; } */

 </style>
</head>
<body>

<!-- NAVBAR -->
  <nav class="site-nav">
    <div class="container">
      <div class="menu-bg-wrap">
        <div class="site-navigation">
          <div class="row g-0 align-items-center">
            <div class="col-2">
              <a href="index.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
            </div>
            <div class="col-8 text-center">
              <form id="searchFormMobile" action="index.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobileTop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form>

              <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                <li class="active"><a href="index.php">Home</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="post.php">Post</a></li>
                <li><a href="category.php">Categories</a></li>
                <li><a href="aboutus.php">About Us</a></li>
              </ul>
            </div>
            <div class="col-2 text-end">
              <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                <span></span>
              </a>

              <form id="searchFormDesktop" action="index.php" method="get" class="search-form d-none d-lg-inline-block">
                <input type="text" name="search" id="searchInputDesktop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>

<!-- HERO -->
<section class="hero-section text-center text-white d-flex align-items-center justify-content-center" 
         style="position: relative; background: url('https://i.pinimg.com/1200x/1d/c8/61/1dc8619487310884c9d631d689ece1e7.jpg') center/cover; height: 60vh;">
  <div class="overlay" style="background-color: rgba(0,0,0,0.5); position:absolute; inset:0; z-index:1;"></div>
  <div class="container position-relative" style="z-index:2;">
    <h1 class="display-4 fw-bold">Selamat Datang di InspirART</h1>
    <p class="lead">Temukan dan bagikan karya seni terbaikmu !!!</p>
  </div>
</section>

<!-- BAGIAN 1 - POPULER (Top 5 berdasarkan like) -->
  <section class="section bg-light">
    <div class="container">
        <h2 class="text-center mb-5 fw-bold text-dark">POPULER</h2>
      <div class="row align-items-stretch retro-layout">
        <div class="col-md-4">
          <?php if (isset($top5[0])): 
                $p = $top5[0]; ?>
          <a href="singledetail.php?id=<?php echo (int)$p['id']; ?>" class="h-entry mb-30 v-height gradient">
            <div class="featured-img" style="background-image: url('<?php echo htmlspecialchars($p['image'] ?: 'images/default.png', ENT_QUOTES); ?>');"></div>
            <div class="text">
              <span class="date"><?php echo date('M. d, Y', strtotime($p['created_at'])); ?></span>
              <h2><?php echo htmlspecialchars($p['title'], ENT_QUOTES); ?></h2>
              <small class="text-muted"><?php echo (int)$p['like_count']; ?> Likes</small>
            </div>
          </a>
          <?php endif; ?>

          <?php if (isset($top5[1])): 
                $p = $top5[1]; ?>
          <a href="singledetail.php?id=<?php echo (int)$p['id']; ?>" class="h-entry v-height gradient">
            <div class="featured-img" style="background-image: url('<?php echo htmlspecialchars($p['image'] ?: 'images/default.png', ENT_QUOTES); ?>');"></div>
            <div class="text">
              <span class="date"><?php echo date('M. d, Y', strtotime($p['created_at'])); ?></span>
              <h2><?php echo htmlspecialchars($p['title'], ENT_QUOTES); ?></h2>
              <small class="text-muted"><?php echo (int)$p['like_count']; ?> Likes</small>
            </div>
          </a>
          <?php endif; ?>
        </div>

        <div class="col-md-4">
          <?php if (isset($top5[2])): 
                $p = $top5[2]; ?>
          <a href="singledetail.php?id=<?php echo (int)$p['id']; ?>" class="h-entry img-5 h-100 gradient">
            <div class="featured-img" style="background-image: url('<?php echo htmlspecialchars($p['image'] ?: 'images/default.png', ENT_QUOTES); ?>');"></div>
            <div class="text">
              <span class="date"><?php echo date('M. d, Y', strtotime($p['created_at'])); ?></span>
              <h2><?php echo htmlspecialchars($p['title'], ENT_QUOTES); ?></h2>
              <small class="text-muted"><?php echo (int)$p['like_count']; ?> Likes</small>
            </div>
          </a>
          <?php endif; ?>
        </div>

        <div class="col-md-4">
          <?php if (isset($top5[3])): 
                $p = $top5[3]; ?>
          <a href="singledetail.php?id=<?php echo (int)$p['id']; ?>" class="h-entry mb-30 v-height gradient">
            <div class="featured-img" style="background-image: url('<?php echo htmlspecialchars($p['image'] ?: 'images/default.png', ENT_QUOTES); ?>');"></div>
            <div class="text">
              <span class="date"><?php echo date('M. d, Y', strtotime($p['created_at'])); ?></span>
              <h2><?php echo htmlspecialchars($p['title'], ENT_QUOTES); ?></h2>
              <small class="text-muted"><?php echo (int)$p['like_count']; ?> Likes</small>
            </div>
          </a>
          <?php endif; ?>

          <?php if (isset($top5[4])): 
                $p = $top5[4]; ?>
          <a href="singledetail.php?id=<?php echo (int)$p['id']; ?>" class="h-entry v-height gradient">
            <div class="featured-img" style="background-image: url('<?php echo htmlspecialchars($p['image'] ?: 'images/default.png', ENT_QUOTES); ?>');"></div>
            <div class="text">
              <span class="date"><?php echo date('M. d, Y', strtotime($p['created_at'])); ?></span>
              <h2><?php echo htmlspecialchars($p['title'], ENT_QUOTES); ?></h2>
              <small class="text-muted"><?php echo (int)$p['like_count']; ?> Likes</small>
            </div>
          </a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </section>

<!-- SEARCH RESULTS (AJAX-driven, shows title + pengirim, title text dark brown) -->
<section id="search-results-section" class="section">
  <div class="container">
    <h2 class="mb-4 text-center" style="color:#fff;">--- Hasil Pencarian ---</h2>
    <div id="search-results-container" class="row g-3"></div>
  </div>
</section>

<!-- Bagian 2 -->
<section class="section bg-light">
  <div class="container">
    <h2 class="text-center mb-5 fw-bold text-dark">Postingan Terbaru</h2>
    <div class="row">
      <?php if ($result && $result->num_rows > 0): ?>
        <?php while($row = $result->fetch_assoc()): ?>
          <div class="col-md-6 col-lg-4 mb-4">
            <div class="blog-entry shadow-sm bg-white rounded p-3 h-100">
               <a href="singledetail.php?id=<?php echo (int)$row['id']; ?>" class="img-link d-block mb-2">
                <img src="<?php echo htmlspecialchars($row['image'] ?: 'images/default.png', ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($row['title'], ENT_QUOTES); ?>" class="post-thumb img-fluid rounded">
              </a>
              <span class="date text-muted small"><?php echo date('M d, Y', strtotime($row['created_at'])); ?></span>
              <h5 class="mt-2 fw-semibold"><a href="singledetail.php?id=<?php echo (int)$row['id']; ?>" class="text-decoration-none text-dark"><?php echo htmlspecialchars($row['title'], ENT_QUOTES); ?></a></h5>
              <p class="postdesc small text-secondary"><?php echo htmlspecialchars($row['deskripsi'], ENT_QUOTES); ?></p>
              <a href="singledetail.php?id=<?php echo (int)$row['id']; ?>" class="btn btn-outline-primary btn-sm mt-auto">Continue Reading</a>
            </div>
          </div>
        <?php endwhile; ?>
      <?php else: ?>
        <p class="text-center text-muted">Tidak ada hasil untuk pencarian "<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>"</p>
      <?php endif; ?>
    </div>

    <!-- PAGINATION -->
    <nav>
      <ul class="pagination justify-content-center mt-4">
         <li class="page-item <?php if($page <= 1) echo 'disabled'; ?>">
          <a class="page-link" href="?search=<?php echo urlencode($search_raw); ?>&page=<?php echo max(1, $page-1); ?>">« Prev</a>
        </li>
        <?php for($i = 1; $i <= $total_pages; $i++): ?>
          <li class="page-item <?php if($i == $page) echo 'active'; ?>">
            <a class="page-link" href="?search=<?php echo urlencode($search_raw); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
          </li>
        <?php endfor; ?>
        <li class="page-item <?php if($page >= $total_pages) echo 'disabled'; ?>">
          <a class="page-link" href="?search=<?php echo urlencode($search_raw); ?>&page=<?php echo min($total_pages, $page+1); ?>">Next »</a>
        </li>
      </ul>
    </nav>
  </div>
</section>

<!-- FOOTER -->
<?php include "footeruser.php"; ?>

<!-- SCRIPTS -->
<script src="js/bootstrap.bundle.min.js"></script>
<script src="js/tiny-slider.js"></script>
<script src="js/flatpickr.min.js"></script>
<script src="js/aos.js"></script>
<script src="js/glightbox.min.js"></script>
<script src="js/navbar.js"></script>
<script src="js/counter.js"></script>
<script src="js/custom.js"></script>

<script>
// Client-side search UI (AJAX) - shows title + pengirim and ensures dark-brown text on cards
document.addEventListener('DOMContentLoaded', function () {
  const mobileInput = document.getElementById('searchInputMobileTop');
  const desktopInput = document.getElementById('searchInputDesktop');
  const mobileForm = document.getElementById('searchFormMobile');
  const desktopForm = document.getElementById('searchFormDesktop');
  const section = document.getElementById('search-results-section');
  const container = document.getElementById('search-results-container');

  function bindInput(input) {
    if (!input) return;
    input.addEventListener('keypress', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        doSearch(input.value.trim());
      }
    });
  }

  // prevent default form submit to enable AJAX; allow normal GET when JS disabled
  [mobileForm, desktopForm].forEach(f => {
    if (!f) return;
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      const input = f.querySelector('input[name="search"]');
      if (input) doSearch(input.value.trim());
    });
  });

  bindInput(mobileInput);
  bindInput(desktopInput);

  function doSearch(keyword) {
    if (!keyword) {
      section.style.display = 'none';
      return;
    }
    fetch(`index.php?ajax=1&search=${encodeURIComponent(keyword)}`)
      .then(resp => resp.json())
      .then(data => {
        if (!Array.isArray(data) || data.length === 0) {
          container.innerHTML = `<div class="col-12"><p class="search-no-results" style="color:#fff;">Tidak ada hasil untuk "<strong>${escapeHtml(keyword)}</strong>"</p></div>`;
        } else {
          container.innerHTML = data.map(post => {
            const img = post.image ? post.image : 'images/default.png';
            const title = escapeHtml(post.title || '');
            const desc = escapeHtml(post.deskripsi || '');
            const author = escapeHtml(post.username || 'Unknown');
            const date = post.created_at ? new Date(post.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' }) : '';
            // each result is a white card so dark-brown text is visible on page brown background
            return `<div class="col-md-4">
                      <div class="search-result-card">
                        <a href="singledetail.php?id=${encodeURIComponent(post.id)}" class="img-link d-block mb-2">
                          <img src="${img}" alt="${title}" class="img-fluid rounded">
                        </a>
                        <div class="search-card-title">${title}</div>
                        <div class="search-card-meta">By ${author} • ${escapeHtml(date)}</div>
                        <div class="search-card-desc">${desc}</div>
                      </div>
                    </div>`;
          }).join('');
        }
        section.style.display = 'block';
        // scroll to results
        window.scrollTo({ top: section.offsetTop - 80, behavior: "smooth" });
      })
      .catch(err => {
        console.error(err);
        container.innerHTML = `<div class="col-12"><p class="search-no-results">Terjadi kesalahan saat mencari.</p></div>`;
        section.style.display = 'block';
      });
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }
});
</script>

</body>
</html>
