-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2025 at 04:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inspirart_db`
--

-- --------------------------------------------------------

--
-- Table structure for tabSle `categories`
--


INSERT IGNORE INTO `categories` (`id`, `name`) VALUES
(1, 'Fashion Designs'),
(2, 'Architecture'),
(3, 'Mural'),
(4, 'Grafitti'),
(5, 'Craft'),
(6, 'Floral'),
(7, 'Photography'),
(8, 'Painting');

COMMIT;