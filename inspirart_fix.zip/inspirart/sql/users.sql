-- phpMyAdmin SQL Dump (Data Dummy Only)
-- version 5.2.1
-- Host: 127.0.0.1
-- Database: `inspirart_db`
-- Only inserts, no table creation

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------
-- DATA DUMMY UNTUK TABEL `users`
-- --------------------------------------------------------

INSERT IGNORE INTO `users` (`username`, `email`, `password`, `profile_img`, `role`, `created_at`) VALUES
('Admin1234', 'admin12@gmail.com', '12345', 'default.jpg', 'admin', '2025-11-05 12:43:58'),
('divia26', 'diviaindah26@gmail.com', '4567', 'default.jpg', 'user', '2025-11-05 12:45:09'),
('diviacantik', 'diviacantik26@gmail.com', '$2y$10$WU6SneFN5YQwQ4IDF6wTzeVRHNyxc92GJveA77yc56vsUm6JBgWxy', 'uploads/profiles/user_3_1762849338.jpg', 'user', '2025-11-05 15:01:19');


COMMIT;

