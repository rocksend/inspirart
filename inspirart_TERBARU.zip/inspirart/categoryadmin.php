<?php
include __DIR__ . '/config.php';

$categories = [];

// Try to load from a dedicated categories table first, otherwise fallback to distinct categories from posts
if ($conn) {
    $check = $conn->query("SHOW TABLES LIKE 'categories'");
    if ($check && $check->num_rows > 0) {
        // check if slug column exists
        $has_slug = false;
        $col = $conn->query("SHOW COLUMNS FROM categories LIKE 'slug'");
        if ($col && $col->num_rows > 0) {
            $has_slug = true;
        }

        if ($has_slug) {
            $res = $conn->query("SELECT id, name, slug FROM categories ORDER BY name");
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $categories[] = [
                        'name' => $r['name'],
                        'slug' => !empty($r['slug']) ? $r['slug'] : rawurlencode($r['name'])
                    ];
                }
            }
        } else {
            // no slug column — select only id,name and generate slug from name
            $res = $conn->query("SELECT id, name FROM categories ORDER BY name");
            if ($res) {
                while ($r = $res->fetch_assoc()) {
                    $categories[] = [
                        'name' => $r['name'],
                        'slug' => rawurlencode($r['name'])
                    ];
                }
            }
        }
    } else {
        // fallback: distinct category values from posts table (try 'category' then 'kategori')
        $res = $conn->query("SELECT DISTINCT category FROM posts WHERE category IS NOT NULL AND category <> '' ORDER BY category");
        if ($res && $res->num_rows > 0) {
            while ($r = $res->fetch_assoc()) {
                $categories[] = [
                    'name' => $r['category'],
                    'slug' => rawurlencode($r['category'])
                ];
            }
        } else {
            $res2 = $conn->query("SELECT DISTINCT kategori FROM posts WHERE kategori IS NOT NULL AND kategori <> '' ORDER BY kategori");
            if ($res2) {
                while ($r = $res2->fetch_assoc()) {
                    $val = $r['kategori'];
                    $categories[] = [
                        'name' => $val,
                        'slug' => rawurlencode($val)
                    ];
                }
            }
        }
    }
}

// Default categories if DB has none
if (empty($categories)) {
    $default = ['Fashion Design','Architecture','Mural','Grafitti','Craft','Floral','Photography','Painting'];
    foreach ($default as $d) {
        $categories[] = ['name' => $d, 'slug' => rawurlencode($d)];
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">
 <link rel="stylesheet" href="fonts/icomoon/style.css">
 <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
 <link rel="stylesheet" href="css/tiny-slider.css">
 <link rel="stylesheet" href="css/aos.css">
 <link rel="stylesheet" href="css/glightbox.min.css">
 <link rel="stylesheet" href="css/style.css">
 <link rel="stylesheet" href="css/flatpickr.min.css">
  <title>InspirART — Category</title>
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    .category-grid { padding: 80px 0; }
    .category-grid .category-block { background:#85431A;color:#fff;text-align:center;padding:50px 20px;border-radius:12px;font-size:1.1rem;font-weight:600;text-transform:capitalize;display:block;transition:all .25s; }
    .category-grid .category-block:hover { transform:translateY(-6px); background:#a05523; text-decoration:none; color:#fff; }
  </style>
</head>
<body>

<!-- NAVBAR -->
  <nav class="site-nav">
    <div class="container">
      <div class="menu-bg-wrap">
        <div class="site-navigation">
          <div class="row g-0 align-items-center">
            <div class="col-2">
              <a href="dashboard.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
            </div>
            <div class="col-8 text-center">
              <form action="dashboard.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobileTop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form>

              <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="profiladmin.php">Profile</a></li>
                <li><a href="indexadmin.php">Post</a></li>
                <li class="active"><a href="categoryadmin.php">Categories</a></li>
                <li><a href="about.php">About Us</a></li>
              </ul>
            </div>
            <div class="col-2 text-end">
              <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                <span></span>
              </a>
               <!-- <form action="dashboard.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobile" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->

              <!-- <form action="dashboard.php" method="get" class="search-form d-none d-lg-inline-block">
                <input type="text" name="search" id="searchInputDesktop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>

<div class="section category-grid">
  <div class="container">
    <div class="row mb-5">
      <div class="col-12 text-center">
        <h2 class="heading">Explore The Categories</h2>
        <p class="text-muted">Temukan berbagai postingan seni dari kategori yang kamu pilih</p>
      </div>
    </div>

    <div class="row g-4">
      <?php foreach ($categories as $cat): ?>
        <div class="col-md-3 col-sm-6">
          <a href="catadmin.php?category=<?php echo rawurlencode($cat['slug']); ?>" class="category-block d-block"><?php echo htmlspecialchars($cat['name'], ENT_QUOTES); ?></a>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>

<!-- FOOTER -->
<?php include "footeradmin.php"; ?>

<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>