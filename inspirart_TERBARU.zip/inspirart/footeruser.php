<?php 
include "config.php";

// Ambil data footer
$footer = $conn->query("SELECT * FROM footer WHERE id = 1")->fetch_assoc() ?: [
    'about_description' => 'Welcome to our website!',
    'about_instagram'   => '#',
    'about_twitter'     => '#',
    'about_facebook'    => '#'
];

// About
$about = [
    "description" => $footer['about_description'] ?? '',
    "instagram"   => $footer['about_instagram'] ?? '#',
    "twitter"     => $footer['about_twitter'] ?? '#',
    "facebook"    => $footer['about_facebook'] ?? '#',
];

// Categories
$categories = [];
$result = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");
while($row = $result->fetch_assoc()){
    $categories[] = $row;
}
$left  = array_slice($categories, 0, 6);
$right = array_slice($categories, 6);

// Recent Post
$recent_posts = $conn->query("SELECT id, title, image, created_at AS date FROM posts ORDER BY created_at DESC LIMIT 2");
$recent = [];
while($row = $recent_posts->fetch_assoc()){
    $recent[] = [
        "title" => $row['title'],
        "link"  => "singledetail.php?id=".$row['id'], // link user
        "image" => $row['image'] ?: 'images/default-post.png',
        "date"  => $row['date']
    ];
}
?>


<head>
    <style>
        .site-footer {
            background-color: #85431A;
            padding: 40px 0;
            border-top: 1px solid #e7e7e7;
        }
        .site-footer h3 {
            font-size: 18px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .site-footer p {
            font-size: 14px;
            color: white;
        }
        .site-footer .social li {
            display: inline-block;
            margin-right: 10px;
        }
        .site-footer .social li a {
            color: #85431A;
            font-size: 16px;
            transition: color 0.3s;
        }
        .site-footer .social li a:hover {
            color: black;
        }
        .site-footer .links li {
            margin-bottom: 10px;
        }
        .site-footer .links li a {
            color: white;
            text-decoration: none;
            transition: color 0.3s;
        }
        .site-footer .links li a:hover {
            color: black;
        }
        .site-footer .post-entry-footer li {
            margin-bottom: 15px;
        }

        .listsamping{
            padding: 0px, 0px, 0px, 30px;
            margin-left: 80px;
        }
        .site-footer .post-entry-footer li a {
            display: flex;
            align-items: center;
            text-decoration: none;
            color: white;
        }
        .site-footer .post-entry-footer li a:hover {
            text-decoration: underline;
        }
        .site-footer .post-entry-footer img {
            width: 70px;
            height: 70px;
            object-fit: cover;
        }
        .site-footer .post-entry-footer .text {
            margin-left: 15px;
        }
        .site-footer .post-entry-footer .text h4 {
            font-size: 16px;
            margin-bottom: 5px;
        }
        .site-footer .post-entry-footer .post-meta {
            font-size: 12px;
            color: white;
        } 
       
    </style>
</head>
<footer class="site-footer">
    <div class="container">
        <div class="row">
            <!-- ABOUT -->
            <div class="col-lg-4">
                <h3 class="mb-4">About</h3>
                <p><?= htmlspecialchars($about['description']) ?></p>
                 <p>Website ini dirancang untuk pengguna yang menyukai seni dan bisa berbagi diskusi</p>
                <h3>Social</h3>
                <ul class="list-unstyled social">
                    <li><a href="<?= htmlspecialchars($about['instagram']) ?>"><span class="icon-instagram"></span></a></li>
                    <li><a href="<?= htmlspecialchars($about['twitter']) ?>"><span class="icon-twitter"></span></a></li>
                    <li><a href="<?= htmlspecialchars($about['facebook']) ?>"><span class="icon-facebook"></span></a></li>
                </ul>
            </div>

           <!-- CATEGORY -->
            <div class="col-lg-4 ps-lg-5">
    <h3 class="mb-4">Category</h3>

    <ul class="list-unstyled float-start links">
        <?php foreach($left as $cat): ?>
            <li>
                <a href="cat.php?category=<?= urlencode($cat['name']) ?>">
                    <?= htmlspecialchars($cat['name']) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>

    <ul class="list-unstyled float-start links">
        <?php foreach($right as $cat): ?>
            <li>
                <a href="cat.php?category=<?= urlencode($cat['name']) ?>">
                    <?= htmlspecialchars($cat['name']) ?>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

            <!-- RECENT POST -->
            <div class="col-lg-4">
                <h3 class="mb-4">Recent Post</h3>
                <ul class="post-entry-footer list-unstyled">
                    <?php foreach($recent as $r): ?>
                        <li>
                            <a href="<?= htmlspecialchars($r['link']) ?>">
                                <img src="<?= htmlspecialchars($r['image']) ?>" class="me-4 rounded" style="width:70px;height:70px;">
                                <div class="text">
                                    <h4><?= htmlspecialchars($r['title']) ?></h4>
                                    <div class="post-meta"><span class="mr-2"><?= date("M. d, Y", strtotime($r['date'])) ?></span></div>
                                </div>
                            </a>
                        </li>
                    <?php endforeach; ?>
                    <?php if(empty($recent)) echo "<li>No recent posts available.</li>"; ?>
                </ul>
            </div>
        </div>

        <div class="row mt-5">
            <div class="col-12 text-center">
                <p>Copyright &copy;<script>document.write(new Date().getFullYear());</script>. All Rights Reserved. &mdash; Designed by <a href="https://untree.co">InspirARTMedia.co</a>  Distributed by <a href="https://themewagon.com">ThemeWagon</a></p>
            </div>
        </div>
    </div>
</footer>
