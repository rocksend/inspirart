<?php
session_start();
include "config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: dashboarduser.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$post_id = intval($_GET['id']);

// validasi: pastikan post milik user
$check = $conn->prepare("SELECT image FROM posts WHERE id = ? AND user_id = ?");
$check->bind_param("ii", $post_id, $user_id);
$check->execute();
$res = $check->get_result();

if ($res->num_rows === 0) {
    die("Tidak boleh menghapus postingan orang lain.");
}

$row = $res->fetch_assoc();
$imagePath = $row['image'];

// hapus file gambar
if (file_exists($imagePath)) {
    unlink($imagePath);
}

// hapus posting
$delete = $conn->prepare("DELETE FROM posts WHERE id = ?");
$delete->bind_param("i", $post_id);
$delete->execute();

header("Location: profile.php?deleted=1");
exit;
?>
