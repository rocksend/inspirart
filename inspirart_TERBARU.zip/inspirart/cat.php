<?php
include __DIR__ . '/config.php';

/* Helper: ambil semua hasil dari prepared stmt (get_result fallback) */
function fetch_stmt_all($stmt) {
    $rows = [];
    if (!$stmt) return $rows;
    if (method_exists($stmt, 'get_result')) {
        $res = $stmt->get_result();
        if ($res) $rows = $res->fetch_all(MYSQLI_ASSOC);
    } else {
        $stmt->store_result();
        $meta = $stmt->result_metadata();
        if ($meta) {
            $fields = [];
            $params = [];
            while ($f = $meta->fetch_field()) {
                $fields[] = $f->name;
                $params[] = null;
            }
            $meta->free();
            $bind_names = [];
            foreach ($params as $i => $v) $bind_names[] = &$params[$i];
            call_user_func_array([$stmt, 'bind_result'], $bind_names);
            while ($stmt->fetch()) {
                $row = [];
                foreach ($fields as $i => $name) $row[$name] = $params[$i];
                $rows[] = $row;
            }
        }
    }
    return $rows;
}

$raw = isset($_GET['category']) ? trim($_GET['category']) : '';
$categoryLabel = $raw ? urldecode($raw) : '';
$posts = [];
$category_id = null;

/* Resolve category_id:
   - jika param numeric -> gunakan sebagai id
   - jika tabel categories ada -> cari berdasarkan name (atau slug jika ada)
*/
if ($raw !== '') {
    if (ctype_digit($raw)) {
        $category_id = (int)$raw;
    } elseif ($conn) {
        $hasCategories = false;
        $res = $conn->query("SHOW TABLES LIKE 'categories'");
        if ($res && $res->num_rows > 0) $hasCategories = true;

        if ($hasCategories) {
            $searchVal = urldecode($raw);

            // apakah ada kolom slug?
            $colCheck = $conn->query("SHOW COLUMNS FROM categories LIKE 'slug'");
            $has_slug_col = ($colCheck && $colCheck->num_rows > 0);

            if ($has_slug_col) {
                $stmt = $conn->prepare("SELECT id, name FROM categories WHERE slug = ? OR name = ? LIMIT 1");
                if ($stmt) {
                    $stmt->bind_param('ss', $searchVal, $searchVal);
                    $stmt->execute();
                    $found = method_exists($stmt, 'get_result') ? $stmt->get_result()->fetch_assoc() : null;
                    if (!$found) {
                        $stmt->bind_result($fid, $fname);
                        if ($stmt->fetch()) $found = ['id'=>$fid,'name'=>$fname];
                    }
                    $stmt->close();
                    if (!empty($found)) {
                        $category_id = (int)$found['id'];
                        $categoryLabel = $found['name'];
                    }
                }
            } else {
                // match by name only
                $stmt = $conn->prepare("SELECT id, name FROM categories WHERE name = ? LIMIT 1");
                if ($stmt) {
                    $stmt->bind_param('s', $searchVal);
                    $stmt->execute();
                    $found = method_exists($stmt, 'get_result') ? $stmt->get_result()->fetch_assoc() : null;
                    if (!$found) {
                        $stmt->bind_result($fid, $fname);
                        if ($stmt->fetch()) $found = ['id'=>$fid,'name'=>$fname];
                    }
                    $stmt->close();
                    if (!empty($found)) {
                        $category_id = (int)$found['id'];
                        $categoryLabel = $found['name'];
                    }
                }
            }
        }
    }
}

/* Ambil posting */
if ($category_id !== null && $conn) {
    $stmt = $conn->prepare("SELECT id, title, deskripsi, image, created_at FROM posts WHERE category_id = ? ORDER BY created_at DESC");
    if ($stmt) {
        $stmt->bind_param('i', $category_id);
        $stmt->execute();
        $posts = fetch_stmt_all($stmt);
        $stmt->close();
    }
} elseif ($raw !== '' && $conn) {
    // fallback: cari kata di title/deskripsi
    $search = '%' . str_replace(['-','+'], ' ', urldecode($raw)) . '%';
    $stmt = $conn->prepare("SELECT id, title, deskripsi, image, created_at FROM posts WHERE title LIKE ? OR deskripsi LIKE ? ORDER BY created_at DESC");
    if ($stmt) {
        $stmt->bind_param('ss', $search, $search);
        $stmt->execute();
        $posts = fetch_stmt_all($stmt);
        $stmt->close();
    }
} elseif ($conn) {
    $stmt = $conn->prepare("SELECT id, title, deskripsi, image, created_at FROM posts ORDER BY created_at DESC");
    if ($stmt) {
        $stmt->execute();
        $posts = fetch_stmt_all($stmt);
        $stmt->close();
    }
}
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo $raw ? 'Category: '.htmlspecialchars($categoryLabel, ENT_QUOTES) : 'All Posts'; ?></title>
   <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="fonts/icomoon/style.css">
    <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
    <link rel="stylesheet" href="css/tiny-slider.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/glightbox.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/flatpickr.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <style>
    .blog-entry { background:#fff;border-radius:10px;padding:20px;box-shadow:0 2px 5px rgba(0,0,0,.1);margin-bottom:20px; position:relative; }
    .blog-entry img { border-radius:10px;width:100%;height:180px;object-fit:cover; }

.site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}


  </style>
</head>
<body>
  <!-- NAVBAR -->
  <nav class="site-nav">
    <div class="container">
      <div class="menu-bg-wrap">
        <div class="site-navigation">
          <div class="row g-0 align-items-center">
            <div class="col-2">
              <a href="dashboarduser.php" class="logo m-0 float-start">InspirART<span class="text-primary"></span></a>
            </div>
            <div class="col-8 text-center">
              <form action="dashboarduser.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobileTop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form>

              <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                <li><a href="dashboarduser.php">Home</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="post.php">Post</a></li>
                <li class="active"><a href="category.php">Categories</a></li>
                <li><a href="aboutus.php">About Us</a></li>
              </ul>
            </div>
            <div class="col-2 text-end">
              <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                <span></span>
              </a>
               <!-- <form action="dashboarduser.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobile" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->

              <!-- <form action="dashboarduser.php" method="get" class="search-form d-none d-lg-inline-block">
                <input type="text" name="search" id="searchInputDesktop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>

  <div class="container py-5">
    <h2 class="text-center mb-4"><?php echo $raw ? 'Category: '.htmlspecialchars($categoryLabel, ENT_QUOTES) : 'All Posts'; ?></h2>

   <div class="row">
      <?php if (empty($posts)): ?>
        <div class="col-12">
          <p class="text-center">Tidak ada postingan untuk kategori "<?php echo htmlspecialchars($categoryLabel, ENT_QUOTES); ?>".</p>
        </div>
      <?php else: foreach ($posts as $post): ?>
        <div class="col-md-6 col-lg-4">
          <div class="blog-entry">
            <?php $img = !empty($post['image']) ? $post['image'] : 'images/placeholder.jpg'; ?>
            <img src="<?php echo htmlspecialchars($img, ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($post['title'] ?? '', ENT_QUOTES); ?>">
            <h5 class="mt-3"><?php echo htmlspecialchars($post['title'] ?? '', ENT_QUOTES); ?></h5>
            <p class="text-muted small"><?php echo !empty($post['created_at']) ? date('M d, Y', strtotime($post['created_at'])) : ''; ?></p>
            <p><?php echo htmlspecialchars(mb_strimwidth($post['deskripsi'] ?? '', 0, 140, '...'), ENT_QUOTES); ?></p>

            <!-- visible link/button -->
            <a href="singledetail.php?id=<?php echo (int)$post['id']; ?>" class="btn btn-outline-primary btn-sm mt-2">Continue Reading</a>

            <!-- stretched link makes the whole card clickable as well -->
            <a href="singledetail.php?id=<?php echo (int)$post['id']; ?>" class="stretched-link" aria-label="Read <?php echo htmlspecialchars($post['title'] ?? '', ENT_QUOTES); ?>"></a>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <!-- FOOTER -->
  <?php include "footeruser.php"; ?>

  <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>