-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2025 at 04:44 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inspirart_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--
--
-- Dumping data for table `posts`
--

INSERT IGNORE INTO `posts` (`id`, `user_id`, `category_id`, `title`, `image`, `deskripsi`, `content`, `created_at`) VALUES
(1, 1, 2, 'Arsitektur Futuristik: Harmoni Antara Bentuk, Gerak, dan Ruang', 'https://i.pinimg.com/1200x/1f/c5/78/1fc578dc185816ed09a7e3ae28b70ec2.jpg', 'Sketsa bangunan pada gambar tersebut menampilkan sebuah desain arsitektur futuristik yang sangat dinamis...', 'Sketsa ini menggunakan dominasi warna hitam dan abu-abu dengan sapuan garis halus yang tumpang tindih, menggambarkan proses eksplorasi ide sang arsitek. Setiap goresan tampak seperti pencarian bentuk terbaik yang mampu memadukan estetika dan fungsi. Melalui pendekatan seperti ini, arsitek berusaha menunjukkan bahwa desain bukan hanya tentang hasil akhir, melainkan perjalanan kreatif untuk menemukan keseimbangan antara imajinasi dan realitas teknis.\r\n        Bentuk lengkung yang dominan dalam desain ini dapat dimaknai sebagai simbol keterbukaan dan fleksibilitas. Dalam dunia arsitektur kontemporer, bentuk organik sering digunakan untuk merepresentasikan harmoni antara manusia, teknologi, dan alam. Tangga serta jalur melingkar yang tampak di sekitar bangunan menunjukkan keterhubungan antar-ruang yang cair dan dinamis, menciptakan kesan bahwa setiap bagian dari struktur memiliki alur cerita tersendiri.\r\n        Selain aspek estetika, desain seperti ini juga mencerminkan kemajuan teknologi dalam dunia arsitektur. Pemodelan digital dan teknik konstruksi modern memungkinkan terciptanya bentuk-bentuk kompleks seperti yang tampak pada gambar. Material inovatif, seperti beton cetak 3D dan baja lentur, kini memberikan kebebasan baru bagi desainer untuk mewujudkan bentuk yang dulu dianggap mustahil secara teknis.\r\n        Walaupun tampak spektakuler, desain futuristik semacam ini tetap menghadapi tantangan besar dalam hal biaya, efisiensi energi, dan keberlanjutan. Struktur melengkung memerlukan perhitungan teknik yang rumit serta material dengan spesifikasi tinggi. Oleh karena itu, setiap ide kreatif perlu disertai perencanaan matang agar dapat diwujudkan tanpa mengorbankan aspek fungsional dan kenyamanan pengguna.\r\n        Secara keseluruhan, sketsa arsitektur ini menggambarkan semangat masa depan—di mana seni, sains, dan teknologi berpadu menjadi satu kesatuan. Bentuknya yang mengalir dan visioner tidak hanya menampilkan wujud fisik sebuah bangunan, tetapi juga mencerminkan cara pandang baru terhadap ruang dan kehidupan urban yang terus berkembang.', '2025-11-06 02:18:07'),
(2, 2, 6, 'Floral: Keindahan Alam dalam Setiap Kelopak', 'https://i.pinimg.com/1200x/d5/5f/b0/d55fb0db850d8c5efeca7b8db168332a.jpg', 'Floral adalah simbol keindahan alami yang tak lekang oleh waktu. Motif dan bentuk yang terinspirasi dari bunga telah menjadi bagian penting dalam berbagai aspek kehidupan manusia...', '        Bunga memiliki bahasa tersendiri yang mampu menyampaikan makna tanpa kata. Setiap jenis bunga membawa simbol dan emosi yang berbeda — mawar melambangkan cinta, lili menandakan kemurnian, sementara lavender mencerminkan ketenangan. Makna-makna ini sering diadaptasi ke dalam karya seni atau desain untuk mengekspresikan perasaan yang sulit diungkapkan secara langsung.\r\n        Dalam dunia seni rupa, tema floral menjadi inspirasi abadi bagi banyak seniman. Lukisan bunga sering kali bukan hanya soal bentuk atau warna, melainkan juga refleksi kehidupan, harapan, dan kefanaan. Claude Monet dengan seri lukisan Water Lilies-nya, misalnya, menampilkan keindahan bunga bukan sekadar objek visual, tetapi juga simbol ketenangan dan keseimbangan batin. Melalui bunga, seniman belajar melihat keindahan dari hal-hal kecil di sekitar mereka.\r\n        Floral juga memiliki peran penting dalam dunia fashion dan desain. Motif bunga digunakan untuk menghadirkan kesan lembut, feminin, dan elegan dalam pakaian maupun interior. Tren floral terus berkembang dari masa ke masa — kadang tampil ramai dan penuh warna, kadang hadir dalam bentuk minimalis dan modern. Namun satu hal yang tak berubah adalah kemampuannya untuk memberikan kesan hidup dan menyenangkan bagi siapa pun yang melihatnya.\r\n        Selain keindahan visual, konsep floral juga mengajarkan manusia tentang filosofi kehidupan. Bunga tumbuh, mekar, lalu layu — menggambarkan siklus alami yang penuh makna. Dari proses itu, kita belajar bahwa keindahan bukanlah sesuatu yang abadi, melainkan hadir dalam setiap momen yang kita hargai. Itulah sebabnya, floral sering dianggap simbol dari perubahan, pertumbuhan, dan keikhlasan.\r\n        Pada akhirnya, floral bukan hanya sekadar motif atau hiasan, tetapi juga wujud hubungan manusia dengan alam. Ia mengingatkan kita bahwa keindahan sejati sering berasal dari kesederhanaan dan keseimbangan. Dalam setiap kelopak yang mekar, tersimpan pesan bahwa kehidupan selalu memiliki ruang untuk tumbuh, berbunga, dan memberikan warna bagi dunia.', '2025-11-05 17:24:49');

COMMIT;
