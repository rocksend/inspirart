
<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "inspirart_db";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

//echo "Koneksi berhasil!"; // Tes dulu, aktifkan ini untuk uji coba

?>
