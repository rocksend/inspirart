// js/postDetail.js
document.addEventListener("DOMContentLoaded", () => {
  if (typeof posts === "undefined") {
    console.error("❌ posts.js belum dimuat!");
    return;
  }

  const params = new URLSearchParams(window.location.search);
  const postId = parseInt(params.get("id")); // ubah string menjadi angka

  const post = posts.find(p => p.id === postId);
  const container = document.getElementById("post-detail");

  if (!post) {
    container.innerHTML = `
      <h2>Postingan tidak ditemukan 😢</h2>
      <a href="index.html" class="btn btn-dark mt-3">Kembali ke Beranda</a>
    `;
  } else {
    document.getElementById("post-title").textContent = post.title;
    document.getElementById("post-date").textContent = post.date;
    document.getElementById("post-image").src = post.image;
    document.getElementById("post-desc").textContent = post.desc;
  }
});
