<?php
include "config.php";
session_start();

if (!isset($_SESSION['user_id'])) {
  die("Silakan login terlebih dahulu.");
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
  die("ID artikel tidak valid.");
}

$post_id = (int)$_GET['id'];
$user_id = $_SESSION['user_id'];

// === Hapus komentar ===
if (isset($_GET['action']) && $_GET['action'] === 'delete_comment' && isset($_GET['comment_id'])) {
  $comment_id = (int)$_GET['comment_id'];

  // Ambil role user
  $role_stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
  $role_stmt->bind_param("i", $user_id);
  $role_stmt->execute();
  $user_role = $role_stmt->get_result()->fetch_assoc()['role'] ?? 'user';
  $role_stmt->close();

  // Cek apakah komentar ada dan siapa pemiliknya
  $check_stmt = $conn->prepare("SELECT user_id FROM comments WHERE id = ?");
  $check_stmt->bind_param("i", $comment_id);
  $check_stmt->execute();
  $comment_data = $check_stmt->get_result()->fetch_assoc();
  $check_stmt->close();

  if ($comment_data && ($comment_data['user_id'] == $user_id || $user_role === 'admin')) {
    $del_stmt = $conn->prepare("DELETE FROM comments WHERE id = ?");
    $del_stmt->bind_param("i", $comment_id);
    $del_stmt->execute();
    $del_stmt->close();
  }

  header("Location: singleadmin.php?id=$post_id");
  exit;
}

// === Ambil data artikel ===
$stmt = $conn->prepare("
  SELECT p.*, u.username
  FROM posts p
  LEFT JOIN users u ON p.user_id = u.id
  WHERE p.id = ?
");
$stmt->bind_param("i", $post_id);
$stmt->execute();
$post = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$post) {
  die("Artikel tidak ditemukan.");
}

// === Tambah komentar ===
if (isset($_POST['submit_comment'])) {
  $comment = trim($_POST['comment']);
  $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : NULL;

  if ($comment !== '') {
    $stmt = $conn->prepare("INSERT INTO comments (post_id, user_id, parent_id, comment) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iiis", $post_id, $user_id, $parent_id, $comment);
    $stmt->execute();
    $stmt->close();
  }

  header("Location: singleadmin.php?id=$post_id");
  exit;
}

// === Toggle Like (Like/Unlike) ===
if (isset($_POST['like'])) {
  $check = $conn->prepare("SELECT id FROM likes WHERE post_id=? AND user_id=?");
  $check->bind_param("ii", $post_id, $user_id);
  $check->execute();
  $check->store_result();

  if ($check->num_rows > 0) {
    // sudah like → unlike (hapus)
    $del = $conn->prepare("DELETE FROM likes WHERE post_id=? AND user_id=?");
    $del->bind_param("ii", $post_id, $user_id);
    $del->execute();
    $del->close();
  } else {
    // belum like → tambahkan
    $ins = $conn->prepare("INSERT INTO likes (post_id, user_id) VALUES (?, ?)");
    $ins->bind_param("ii", $post_id, $user_id);
    $ins->execute();
    $ins->close();
  }

  $check->close();

  header("Location: singleadmin.php?id=$post_id");
  exit;
}

// === Ambil semua komentar ===
$cq = $conn->prepare("
  SELECT c.*, u.username 
  FROM comments c 
  JOIN users u ON c.user_id = u.id 
  WHERE c.post_id = ?
  ORDER BY c.created_at ASC
");
$cq->bind_param("i", $post_id);
$cq->execute();
$comments = $cq->get_result();

// === Ambil jumlah like ===
$lq = $conn->prepare("SELECT COUNT(*) AS total FROM likes WHERE post_id=?");
$lq->bind_param("i", $post_id);
$lq->execute();
$likes_count = $lq->get_result()->fetch_assoc()['total'];
$lq->close();

// === Cek apakah user sudah like ===
$liked = false;
$check = $conn->prepare("SELECT id FROM likes WHERE post_id=? AND user_id=?");
$check->bind_param("ii", $post_id, $user_id);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) {
  $liked = true;
}
$check->close();
?>

<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>InspirART - Detail Post</title>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:wght@400;600;700&display=swap" rel="stylesheet">

  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.8.1/font/bootstrap-icons.css">
  <link rel="stylesheet" href="css/tiny-slider.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/glightbox.min.css">
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/flatpickr.min.css">

  <style>
    .btn-delete-comment {
      color: white;
      background-color: #dc3545;
      border: none;
      padding: 3px 8px;
      font-size: 12px;
      border-radius: 5px;
      text-decoration: none;
      margin-left: 10px;
    }
    .btn-delete-comment:hover {
      background-color: #c82333;
      color: white;
    }
    
    .site-nav {
  position: sticky;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9999;
  width: 100%;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
}
  </style>
</head>

<body>

<!-- NAVBAR -->
  <nav class="site-nav">
    <div class="container">
      <div class="menu-bg-wrap">
        <div class="site-navigation">
          <div class="row g-0 align-items-center">
            <div class="col-2">
              <a href="indexadmin.php" class="logo m-0 float-start">InspirART<span class="text-primary">.</span></a>
            </div>
            <div class="col-8 text-center">
              <form action="indexadmin.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobileTop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form>

              <ul class="js-clone-nav d-none d-lg-inline-block text-start site-menu mx-auto">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="profiladmin.php">Profile</a></li>
                <li class="active"><a href="indexadmin.php">Post</a></li>
                <li><a href="categoryadmin.php">Categories</a></li>
                <li><a href="about.php">About Us</a></li>
              </ul>
            </div>
            <div class="col-2 text-end">
              <a href="#" class="burger ms-auto float-end site-menu-toggle js-menu-toggle d-inline-block d-lg-none light">
                <span></span>
              </a>
               <!-- <form action="indexadmin.php" method="get" class="search-form d-inline-block d-lg-none">
                <input type="text" name="search" id="searchInputMobile" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->

              <!-- <form action="indexadmin.php" method="get" class="search-form d-none d-lg-inline-block">
                <input type="text" name="search" id="searchInputDesktop" class="form-control" placeholder="Search..." value="<?php echo htmlspecialchars($search_raw, ENT_QUOTES); ?>">
                <span class="bi-search"></span>
              </form> -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>

<!-- BANNER USER -->
<section class="section py-3" id="post-banner">
  <div class="container d-flex align-items-center">
    <img id="post-user-img" src="<?php echo htmlspecialchars($post['profile_img'] ?? 'images/default-user.png'); ?>" 
     alt="User" class="rounded-circle me-3" width="60" height="60">
    <div>
      <h6 class="mb-0" id="post-user-name"><?php echo htmlspecialchars($post['username'] ?? 'Anonymous'); ?></h6>
    </div>
  </div>
</section>

<!-- DETAIL POST -->
<section class="section bg-light" id="detailpost">
  <div class="container">
    <div id="post-detail" class="text-center">
      <h1 class="ms-2 mb-3"><?php echo htmlspecialchars($post['title']); ?></h1>
      <form method="post" style="margin-top:10px;">
        <button name="like" style="border:none;background:none;cursor:pointer;font-size:20px;color:<?= $liked ? 'red' : '#aaa'; ?>;">❤️</button>
        <span><?= $likes_count ?> Likes</span>
      </form>

      <h6 class="text-muted"><?php echo date('M d, Y', strtotime($post['created_at'])); ?></h6>
      <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" 
           class="img-fluid rounded mb-4" style="max-width:600px">
      <p class="lead"><?php echo nl2br(htmlspecialchars($post['deskripsi'])); ?></p>
      <p class="lead"><?php echo nl2br(htmlspecialchars($post['content'] ?? '')); ?></p>
    </div>
  </div>
</section>

<!-- Komentar -->
<section class="comments mt-4">
  <h4 class="ms-4">Komentar</h4>
  <form method="post" class="ms-4 mb-3">
    <textarea name="comment" class="form-control" placeholder="Tulis komentar..." required></textarea>
    <button type="submit" name="submit_comment" class="btn btn-primary mt-2">Kirim</button>
  </form>

  <?php
  $all_comments = $comments->fetch_all(MYSQLI_ASSOC);

  function tampilKomentar($all, $parent_id = null, $margin = 0) {
    foreach ($all as $row) {
      if ($row['parent_id'] == $parent_id) {
        echo "<div style='margin-left: {$margin}px; border-left: 2px solid #eee; padding-left:10px; margin-top:10px;'>";
        echo "<strong>{$row['username']}</strong> • <small>{$row['created_at']}</small><br>";
        echo nl2br(htmlspecialchars($row['comment']));

        // Tombol hapus komentar (pemilik atau admin)
        if (isset($_SESSION['user_id']) && ($_SESSION['user_id'] == $row['user_id'] || ($_SESSION['role'] ?? '') === 'admin')) {
          echo " <a href='singleadmin.php?id={$_GET['id']}&action=delete_comment&comment_id={$row['id']}' onclick=\"return confirm('Yakin ingin menghapus komentar ini?');\" class='btn-delete-comment'>Hapus</a>";
        }

        // Form balasan
        echo "<form method='post' class='ms-4 mb-2 mt-2'>
                <input type='hidden' name='parent_id' value='{$row['id']}'>
                <textarea name='comment' placeholder='Balas komentar...' class='form-control' required></textarea>
                <button type='submit' name='submit_comment' class='btn btn-sm btn-secondary mt-1'>Balas</button>
              </form>";

        tampilKomentar($all, $row['id'], $margin + 30);
        echo "</div>";
      }
    }
  }
  ?>

  <section class="comments ms-4 mt-4">
    <?php tampilKomentar($all_comments); ?>
  </section>
</section>

<br><br>

<!-- FOOTER -->
<?php include "footeruser.php"; ?>

</body>
</html>
